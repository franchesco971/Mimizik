<?php
//show header
get_header();

//get blog layout
$layout=get_option('themex_blog_layout');
if($layout=='left') {
?>
	<div class="one-third column">
		<?php get_sidebar(); ?>
	</div>
	<div class="two-third column last">
<?php } else { ?>
	<div class="two-third column">
<?php } ?>
		<div class="content-block">
			<?php if (have_posts()) : ?>
			<div class="block-content">
				<div class="featured-blog">
					<?php while (have_posts()) : the_post(); ?>
					<div <?php post_class('post'); ?>>
						<?php if(has_post_thumbnail()) { ?>
						<div class="one-fourth column featured-image">
							<a href="<?php the_permalink(); ?>"><img src="<?php echo themex_thumbnail($post->ID,440); ?>" class="fullwidth" alt="<?php the_title(); ?>" /></a>
						</div>
						<div class="five-twelfth-inner column last post-content">
						<?php } else { ?>
						<div class="post-content">
						<?php } ?>
							<h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<?php the_excerpt(); ?>
							<div class="post-meta">										
								<a href="<?php the_permalink(); ?>" class="button small"><span><?php _e('Read More','replay'); ?></span></a>
								<div class="post-info">
									<?php 
									themex_time();
									if(comments_open()) { 
									?>
									|&nbsp;<a href="<?php comments_link(); ?>"><?php comments_number( '0 '.__('Comments','replay'), '1 '.__('Comment','replay'), '% '.__('Comments','replay') ); ?></a>
									<?php } ?>
								</div>
								<div class="clear"></div>
							</div>
						</div>
					</div><!--/ post-->
					<?php endwhile; ?>					
					<div class="pagination">
					<?php themex_pagination(); ?>
					</div><!--/ pagination-->
				</div>						
			</div>
			<?php else: ?>
			<div class="block-title">
				<span><?php _e('Nothing Found','replay') ?></span>
			</div>
			<div class="block-content"><?php _e('Sorry, no posts matched your criteria','replay') ?>.</div>
			<?php endif; ?>
		</div>
	</div>
<?php if($layout!='left') { ?>
<div class="one-third column last">
	<?php get_sidebar(); ?>
</div>
<?php } ?>
<?php get_footer(); ?>