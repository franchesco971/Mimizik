<?php
/*
Template Name: Blog
*/

//show header
get_header();

//page content
if (have_posts()) : while (have_posts()) : the_post();
	the_content();
endwhile; endif;

//blog title
$title=__('Latest News','replay');
if(get_option('themex_blog_title')) {
	$title=get_option('themex_blog_title');
}

//blog category
$category=get_post_meta($post->ID,'page_blog_category',true);
$categories=null;
if($category!='0' && $category!='') {
	$categories=array($category);
}

//get posts
$paged = (get_query_var('page')) ? get_query_var('page') : 1;
query_posts(array(
	'post_type' =>'post',
	'paged' => $paged,
	'category__in' => $categories,
));

//get blog layout
$layout=get_option('themex_blog_layout');
if($layout=='left') {
?>
	<div class="one-third column">
		<?php get_sidebar(); ?>
	</div>
	<div class="two-third column last">
<?php } else { ?>
	<div class="two-third column">
<?php } ?>
		<div class="content-block">
			<?php if (have_posts()) : ?> 
			<div class="block-title">
				<span><?php echo $title; ?></span>
			</div>
			<div class="block-content">
				<div class="featured-blog">
					<?php while (have_posts()) : the_post(); ?>
					<div <?php post_class('post'); ?>>
						<?php if(has_post_thumbnail()) { ?>
						<div class="one-fourth column featured-image">
							<a href="<?php the_permalink(); ?>"><img src="<?php echo themex_thumbnail($post->ID,440); ?>" class="fullwidth" alt="<?php the_title(); ?>" /></a>
						</div>
						<div class="five-twelfth-inner column last post-content">
						<?php } else { ?>
						<div class="post-content">
						<?php } ?>
							<h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<?php the_excerpt(); ?>
							<div class="post-meta">										
								<a href="<?php the_permalink(); ?>" class="button small"><span><?php _e('Read More','replay'); ?></span></a>
								<div class="post-info">
									<?php 
									themex_time();
									if(comments_open()) { 
									?>
									|&nbsp;<a href="<?php comments_link(); ?>"><?php comments_number( '0 '.__('Comments','replay'), '1 '.__('Comment','replay'), '% '.__('Comments','replay') ); ?></a>
									<?php } ?>
								</div>									
								<div class="clear"></div>
							</div>
						</div>
					</div><!--/ post-->
					<?php endwhile; ?>
					<div class="pagination">
					<?php 
					themex_pagination();
					wp_reset_query();
					?>
					</div><!--/ pagination-->
				</div>						
			</div>
			<?php else: ?>
			<div class="block-title">
				<span><?php _e('Nothing Found','replay') ?></span>
			</div>
			<div class="block-content"><?php _e('Sorry, no posts matched your criteria','replay') ?>.</div>
			<?php endif; ?>
		</div>
	</div>
<?php if($layout!='left') { ?>
<div class="one-third column last">
	<?php get_sidebar(); ?>
</div>
<?php } ?>
<?php get_footer(); ?>