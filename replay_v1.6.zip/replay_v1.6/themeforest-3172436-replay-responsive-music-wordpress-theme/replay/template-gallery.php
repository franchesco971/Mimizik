<?php 
/*
Template Name: Gallery
*/

//show header
get_header();

//page content
if (have_posts()) : while (have_posts()) : the_post();
	the_content();
endwhile; endif;

//page layout
$layout='one-third';
$columns=3;
$count=0;
if(get_option('themex_gallery_layout')) {
	$layout=get_option('themex_gallery_layout');
}
if($layout=='one-fourth') {
	$columns=4;
}

//thumbs height
$height=null;
if(get_option('themex_gallery_height')) {
	$height=intval(get_option('themex_gallery_height'));
}

//galleries per page
$limit=9;
if(get_option('themex_gallery_limit')) {
	$limit=get_option('themex_gallery_limit');
}

//gallery category
$category=get_post_meta($post->ID,'page_galleries_category', true);
if($category!='' && $category!='0') {
	$category=get_term( intval($category), 'gallery_category' );
	if(isset($category->slug)) {
		$category=$category->slug;
	}
}

//gallery query
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
query_posts(array(
	'post_type' =>'gallery',
	'posts_per_page' => $limit,
	'paged' => $paged,
	'gallery_category' => $category,
	'meta_key' => '_thumbnail_id',
));
?>
<div class="listing-block">
	<?php
	if (have_posts()) : while (have_posts()) : the_post();
	$count++;
	if(has_post_thumbnail()) {
	?>
		<div class="<?php echo $layout; ?> column <?php if ($count==$columns) echo 'last'; ?>">
			<div class="gallery-thumbnail">
				<a href="<?php the_permalink(); ?>" class="thumbnail-border"><img src="<?php echo themex_thumbnail($post->ID, 470, $height); ?>" class="fullwidth" alt="" /></a>
				<a class="caption" href="<?php the_permalink(); ?>">
					<span><?php the_title(); ?></span>
				</a>
				<div class="gallery-background">
					<div class="left-bg"></div>
					<div class="right-bg"></div>
				</div>
			</div>
		</div>
		<?php
		if($count==$columns) {
			$count=0;
		?>
		<div class="clear"></div>
		<?php } ?>
	<?php
	}
	endwhile; 
	endif;
	?>
	<div class="pagination">
	<?php themex_pagination(); ?>
	</div><!--/ pagination-->
	<div class="clear"></div>
</div><!--/ listing block-->
<?php get_footer(); ?>