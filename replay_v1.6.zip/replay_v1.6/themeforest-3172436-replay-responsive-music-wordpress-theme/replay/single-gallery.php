<?php 
//show header
get_header();

//post content
if (have_posts()) : while (have_posts()) : the_post();
?>
<div class="content-block">
	<div class="block-title">
		<span><?php the_title(); ?></span>
		<div class="carousel-slider-arrow arrow arrow-right"></div>
		<div class="carousel-slider-arrow arrow arrow-left"></div>
	</div>
	<div class="block-content">
		<div class="fade-slider">
			<ul>
				<?php
				//get gallery images
				if(get_post_meta($post->ID,'gallery_images',true)!='') {
					parse_str(get_post_meta($post->ID,'gallery_images',true),$images);
				}
				
				if(is_array($images)) {		
					foreach($images as $img_src) {
				?>
				<li><img src="<?php echo THEMEX_URI.'extensions/timthumb/timthumb.php?src='.urlencode($img_src).'&amp;w=900'; ?>" alt="" /></li>
				<?php					
					}
				}
				?>
			</ul>
		</div>
	</div>
</div>
<?php
$current_id=$post->ID;
endwhile; endif;

//page layout
$layout='one-third';
$limit=3;
if(get_option('themex_gallery_layout')) {
	$layout=get_option('themex_gallery_layout');
}
if($layout=='one-fourth') {
	$limit=4;
}

//thumbs height
$height=null;
if(get_option('themex_gallery_height')) {
	$height=intval(get_option('themex_gallery_height'));
}

//posts count
$posts_count=6;
if(get_option('themex_gallery_count')) {
	$posts_count=intval(get_option('themex_gallery_count'));
}

//order
$order='date';
if(get_option('themex_gallery_order')) {
	$order=get_option('themex_gallery_order');
}

//filters
$filters=null;
if($order=='related') {
	$artists=array();
	parse_str(get_post_meta($post->ID,'gallery_artists',true),$artists);	
	$filters=array('artists'=>$artists);
}

//get posts
$galleries=themex_get_posts('gallery',array('ID','title','permalink'),$posts_count,$filters, $order, array($current_id));
?>
<div class="listing-block">
<?php
if(get_option('themex_gallery_related')!='true') {
	$count=0;
	foreach($galleries as $gallery) {
	if(has_post_thumbnail($gallery['ID'])) {
	$count++;
?>
	<div class="<?php echo $layout; ?> column <?php if ($count==$limit) echo 'last'; ?>">
		<div class="gallery-thumbnail">
			<a href="<?php echo $gallery['permalink']; ?>" class="thumbnail-border"><img src="<?php echo themex_thumbnail($gallery['ID'], 470, $height); ?>" class="fullwidth" alt="" /></a>
			<a class="caption" href="<?php echo $gallery['permalink']; ?>">
				<span><?php echo $gallery['title']; ?></span>
			</a>
			<div class="gallery-background">
				<div class="left-bg"></div>
				<div class="right-bg"></div>
			</div>
		</div>
	</div>
	<?php
	if($count==$limit) {
		$count=0;
	?>
	<div class="clear"></div>
<?php
		}
		}
	} 
}
?>
</div><!--/ listing block-->
<?php get_footer(); ?>