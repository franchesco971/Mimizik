<?php 
//show header
get_header();
if (have_posts()) : while (have_posts()) : the_post();
	//page content
	the_content();
endwhile; endif;
//show footer
get_footer(); 
?>