<?php 
/*
Template Name: Releases
*/

//show header
get_header();

//page content
if (have_posts()) : while (have_posts()) : the_post();
	the_content();
	$current_url=get_permalink($post->ID);
endwhile; endif;

//page layout
$layout=get_option('themex_releases_layout');
$columns=3;
if($layout=='fullwidth') {
	$columns=4;
}

//releases filter
$artists = get_posts( array('post_type' => 'artist', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC') );
if(!empty($artists)) {
	$releases_filter='<li ';	
	if(!isset($_GET['a'])) {
		$releases_filter.='class="current"';
	}	
	$releases_filter.='><h5><a href="'.$current_url.'">'.__('All Artists', 'replay').'</a></h5></li>';
	
	foreach($artists as $artist) {
		$releases_filter.='<li ';
		if(isset($_GET['a']) && intval($_GET['a'])==$artist->ID) {
			$releases_filter.='class="current"';
		}
		$releases_filter.=' ><h5><a href="'.$current_url.'?a='.$artist->ID.'">'.$artist->post_title.'</a></h5></li>';
	}
}

//releases category
$category=get_post_meta($post->ID,'page_releases_category', true);
if($category!='' && $category!='0') {
	$category=get_term( intval($category), 'release_category' );
	if(isset($category->slug)) {
		$category=$category->slug;
	}
}

//releases per page
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$limit=9;
if(get_option('themex_releases_limit')) {
	$limit=get_option('themex_releases_limit');
}

//releases query args
if(isset($_GET['a']) && intval($_GET['a'])!=0) {
	$atts=themex_get_query(themex_get_posts('release',array('ID'),-1, array('artists'=>$_GET['a'])), $limit, $paged);
} else {
	$atts=array(
		'post_type' =>'release',
		'posts_per_page' => $limit,
		'paged' => $paged,
		'release_category' => $category,
		'meta_key' => '_thumbnail_id',
	);
}

//releases query
query_posts($atts);

if($layout=='left') {
?>
	<div class="one-fourth column">
		<?php if(get_option('themex_releases_filter')!='true') { ?>
		<div class="content-block widget releases-filter">
			<div class="block-title"><span><?php _e('Artists','replay'); ?></span></div>
			<div class="block-content">
				<ul><?php echo $releases_filter; ?></ul>
			</div>
		</div>
		<?php } ?>	
		<?php get_sidebar(); ?>
	</div>
	<div class="three-fourth column last">
<?php } else if($layout=='fullwidth') { ?>
	<div class="listing-wrapper">
<?php } else { ?>
	<div class="three-fourth column">
<?php } ?>
	<div class="listing-block">
		<div class="releases-listing">
			<?php 
			$count=0;
			if (have_posts()) : while (have_posts()) : the_post(); 
			$count++;
			?><div class="one-fourth column <?php if($count==$columns) { echo 'last'; $count=0; } ?>">
					<div class="release-thumbnail">
						<div class="release-cover">
							<a href="<?php the_permalink(); ?>"><img src="<?php echo themex_thumbnail($post->ID,460); ?>" class="fullwidth" alt="" /></a>
						</div>
						<h4 class="release-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
						<h6 class="release-artist"><?php echo themex_artists(get_post_meta($post->ID,'release_artists',true)); ?></h6>
						<div class="release-meta">
							<?php echo themex_links($post->ID); ?>
							<div class="release-info"><?php echo get_post_meta($post->ID,'release_date',true); ?></div>
							<div class="clear"></div>								
						</div>
					</div>
				</div>
			<?php
			endwhile;
			endif;
			?>			
			<div class="clear"></div>
		</div>
		<div class="pagination">
		<?php themex_pagination(); ?>
		</div><!--/ pagination-->
	</div><!--/ listing block-->	
</div>
<?php if($layout!='left' && $layout!='fullwidth') { ?>
<div class="one-fourth column last">
	<?php if(get_option('themex_releases_filter')!='true') { ?> 
	<div class="content-block widget releases-filter">
		<div class="block-title"><span><?php _e('Artists','replay'); ?></span></div>
		<div class="block-content">
			<ul><?php echo $releases_filter; ?></ul>
		</div>
	</div>
	<?php
	}	
	wp_reset_query(); 
	get_sidebar(); 
	?>
</div>
<?php } ?>
<?php get_footer(); ?>