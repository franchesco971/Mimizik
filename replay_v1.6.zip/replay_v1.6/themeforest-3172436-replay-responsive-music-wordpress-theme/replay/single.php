<?php
//show header
get_header();

//get blog layout
$layout=get_option('themex_blog_layout');
if($layout=='left') {
?>
	<div class="one-third column">
		<?php get_sidebar(); ?>
	</div>
	<div class="two-third column last">
<?php } else { ?>
	<div class="two-third column">
<?php } ?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<?php if(has_post_thumbnail()) { ?>
		<div class="bordered-image">
			<img src="<?php echo themex_thumbnail($post->ID,610); ?>" class="fullwidth" alt="<?php the_title(); ?>" />
		</div>
		<?php } ?>
		<div class="content-block single-post">
			<div class="block-content">
				<h1 class="post-title"><?php the_title(); ?></h1>
				<?php the_content(); ?>				
				<div class="post-meta">
					<div class="post-info"><?php themex_time(); ?> <?php _e('in','replay'); ?> <?php the_category(', '); ?></div>
					<div class="post-tags">
						<?php the_tags('','',''); ?>
					</div>
				</div>					
			</div>
		</div>
		<?php comments_template(); ?>
	<?php endwhile; endif; ?>
	</div>	
<?php if($layout!='left') { ?>
<div class="one-third column last">
	<?php get_sidebar(); ?>
</div>
<?php } ?>
<?php get_footer(); ?>