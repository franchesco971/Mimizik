<?php
//get slider type
$slider_type=get_option('themex_slider_type');

//slider pause
$pause=0;
if(get_option('themex_slider_pause')) {
	$pause=get_option('themex_slider_pause');
}

//slider speed
$speed=400;
if(get_option('themex_slider_speed')) {
	$speed=get_option('themex_slider_speed');
}

//slider mousewheel
$mousewheel='false';
if(get_option('themex_slider_mousewheel')) {
	$mousewheel=get_option('themex_slider_mousewheel');
}

//query slides
$query=new WP_Query(array(
	'post_type' =>'slide',
	'showposts' => -1,
));

//check posts existance
if(!$query->have_posts()) {
	return;
}

if($slider_type=='fade') {
?>
<div class="main-fade-slider wrapper">
	<div class="ribbon-slider-background">
	</div>
	<div class="fade-slider container">
		<ul>
			<?php 
			while($query->have_posts()) : $query->the_post();
				$slide_link=get_post_meta($post->ID,'slide_link',true);
				$video_code=get_post_meta($post->ID,'slide_video_code',true);
				
				if($video_code!='') {
				?>
				<li>
					<div class="embedded-video" id="video-<?php the_ID(); ?>"><?php echo html_entity_decode(stripslashes_deep($video_code)); ?></div>
				</li>
				<?php } else if(has_post_thumbnail()) { ?>
				<li>
					<?php if($slide_link!='') {	?>
					<a href="<?php echo $slide_link; ?>">
					<?php } ?>
					<img class="fullwidth" src="<?php echo themex_thumbnail($post->ID,940); ?>" alt="" />
					<?php if($slide_link!='') { ?>
					</a>
					<?php } ?>
					<?php if(trim($post->post_content) != '') { ?>
					<div class="ribbon-caption">
						<?php if($slide_link!='') { ?>
						<a href="<?php echo $slide_link; ?>" class="ribbon-caption-title">
						<?php } else { ?>
						<div class="ribbon-caption-title">
						<?php } ?>						
							<span class="ribbon-caption-background"></span>
							<span><?php echo get_the_content(); ?></span>
						<?php if($slide_link!='') { ?>
						</a>
						<?php } else { ?>
						</div>
						<?php } ?>
					</div>
					<?php } ?>
				</li>
				<?php
				}
			endwhile; 
			?>	
		</ul>
		<div class="arrow arrow-left"></div>
		<div class="arrow arrow-right"></div>
		<input type="hidden" class="slider-pause" value="<?php echo $pause; ?>" />
		<input type="hidden" class="slider-speed" value="<?php echo $speed; ?>" />
		<input type="hidden" class="slider-mousewheel" value="<?php echo $mousewheel; ?>" />
		<div class="clear"></div>		
	</div>
</div><!--/ main slider-->
<?php } else { ?>
<div class="ribbon-slider-container limit-left">
	<div class="ribbon-slider-background">	
	</div>
	<div class="ribbon-slider">
		<ul>
			<?php 
			while($query->have_posts()) : $query->the_post();
				$slide_link=get_post_meta($post->ID,'slide_link',true);
				$video_code=get_post_meta($post->ID,'slide_video_code',true);
			
				//slide width
				$slide_width=300;
				if(get_post_meta($post->ID,'slide_width',true)!='') {
					$slide_width=get_post_meta($post->ID,'slide_width',true);
				}
				
				if($video_code!='') {
				?>
				<li class="slide-<?php echo $slide_width; ?>">
					<div class="embedded-video" id="video-<?php the_ID(); ?>"><?php echo html_entity_decode(stripslashes_deep($video_code)); ?></div>
				</li>
				<?php
				} else if(has_post_thumbnail()) {
				?>
				<li class="slide-<?php echo $slide_width; ?>">
					<?php
					$slide_link=get_post_meta($post->ID,'slide_link',true);
					if($slide_link!='') {
					?>
					<a href="<?php echo $slide_link; ?>">
					<?php } ?>
					<img class="fullwidth" src="<?php echo themex_thumbnail($post->ID,$slide_width); ?>" alt="" />
					<?php if($slide_link!='') { ?>
					</a>
					<?php } ?>
					<?php if(trim($post->post_content) != '') { ?>
					<div class="ribbon-caption">
						<?php if($slide_link!='') { ?>
						<a href="<?php echo $slide_link; ?>" class="ribbon-caption-title">
						<?php } else { ?>
						<div class="ribbon-caption-title">
						<?php } ?>
							<span><?php echo get_the_content(); ?></span>
							<span class="ribbon-caption-background"></span>
						<?php if($slide_link!='') { ?>
						</a>
						<?php } else { ?>
						</div>
						<?php } ?>
					</div>
					<?php } ?>
				</li>
				<?php 
				}
			endwhile; 
			?>
		</ul>
		<input type="hidden" class="slider-pause" value="<?php echo $pause; ?>" />
		<input type="hidden" class="slider-speed" value="<?php echo $speed; ?>" />
		<input type="hidden" class="slider-mousewheel" value="<?php echo $mousewheel; ?>" />
	</div>
</div><!--/ ribbon slider-->
<?php } ?>