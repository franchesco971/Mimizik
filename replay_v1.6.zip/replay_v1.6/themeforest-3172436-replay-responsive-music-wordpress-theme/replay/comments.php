<?php if(comments_open()) { ?>
<div class="content-block" id="comments">
	<div class="block-title"><span><?php _e('Comments','replay'); ?></span></div>
	<div class="block-content">
		<?php
		if (!empty($_SERVER['SCRIPT_FILENAME']) && 'template-comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
			die ('Please do not load this page pointly.');

		 if ( get_comments_number()!=0 ) :
		 ?>
		<div class="comment-list">
			<ol id="comments">
				<?php wp_list_comments('avatar_size=40&callback=themex_comment'); ?>
			</ol>
		</div><!--/ comments-->
		<?php endif; ?>
		<div class="pagination">
			<?php paginate_comments_links(); ?>
		</div><!--/ pagination-->
		<?php 
		$defaults = array(
			'comment_field'        => '<div class="field-wrapper"><textarea id="comment" placeholder="'.__('Comment','replay').'" name="comment" cols="45" rows="8" aria-required="true"></textarea></div>',
			'comment_notes_before' => '',
			'comment_notes_after'  => '',
			'title_reply'          => '',
			'title_reply_to'       => '',
		);
		comment_form($defaults);
		?>
	</div>
</div>
<?php } ?>