<?php 
//show header
get_header();

//post content
if (have_posts()) : while (have_posts()) : the_post();
?>
<div class="content-block">
	<div class="block-title">
		<span><?php the_title(); ?></span>
	</div>
	<div class="block-content">
		<div class="embedded-video">
			<?php echo html_entity_decode(stripslashes_deep(get_post_meta($post->ID,'video_code',true))); ?>
		</div>
	</div>
</div>
<?php
$current_id=$post->ID;
endwhile; endif;

//page layout
$layout='one-third';
$limit=3;
if(get_option('themex_video_layout')) {
	$layout=get_option('themex_video_layout');
}
if($layout=='one-fourth') {
	$limit=4;
}

//thumbs height
$height=null;
if(get_option('themex_video_height')) {
	$height=intval(get_option('themex_video_height'));
}

//posts count
$posts_count=6;
if(get_option('themex_video_count')) {
	$posts_count=intval(get_option('themex_video_count'));
}

//order
$order='date';
if(get_option('themex_video_order')) {
	$order=get_option('themex_video_order');
}

//filters
$filters=null;
if($order=='related') {
	$artists=array();
	parse_str(get_post_meta($post->ID,'video_artists',true),$artists);	
	$filters=array('artists'=>$artists);
}

//get posts
$videos=themex_get_posts('video',array('ID','title','permalink'),$posts_count,$filters, $order, array($current_id));
?>
<div class="listing-block">
<?php
if(get_option('themex_video_related')!='true') {
	$count=0;
	foreach($videos as $video) {
	if(has_post_thumbnail($video['ID'])) {
	$count++;
?>
	<div class="<?php echo $layout; ?> column <?php if ($count==$limit) echo 'last'; ?>">
		<div class="video-thumbnail">
			<a href="<?php echo $video['permalink']; ?>" class="thumbnail-border"><img src="<?php echo themex_thumbnail($video['ID'], 470, $height); ?>" class="fullwidth" alt="" /></a>
			<a class="caption" href="<?php echo $video['permalink']; ?>">
				<span><?php echo $video['title']; ?></span>
			</a>
		</div>
	</div>
	<?php
	if($count==$limit) {
		$count=0;
	?>
	<div class="clear"></div>
<?php
		}
		}
	} 
}
?>
</div><!--/ listing block-->
<?php get_footer(); ?>