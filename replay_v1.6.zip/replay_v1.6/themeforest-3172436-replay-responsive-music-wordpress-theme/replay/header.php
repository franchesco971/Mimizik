<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php bloginfo('name'); ?><?php wp_title('|', true, 'left'); ?></title>	
	
	<!-- Global JS Vars -->
	<script type="text/javascript">
		var template_directory = '<?php echo THEME_URI; ?>';
		var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
	</script>
	
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div class="wrapper header">
		<div class="supheader wrapper">
			<div class="container">
				<div class="logo">
					<a href="<?php echo home_url(); ?>"><?php themex_logo(); ?></a>
				</div><!--/ logo-->
				<?php if(get_option('users_can_register') && !is_user_logged_in()) { ?>
				<div class="user-links">
					<div class="button-container">
						<a href="#" class="button small dark login-link"><span><?php _e('Sign In','replay'); ?></span></a>
					</div>		
				</div><!--/ user links-->	
				<?php } ?>
				<div class="social-links">
					<?php if(get_option('themex_rss_link')) { ?><a class="rss" href="<?php echo get_option('themex_rss_link'); ?>" target="_blank" title="RSS"></a><?php } ?>	
					<?php if(get_option('themex_google_link')) { ?><a target="_blank" href="<?php echo get_option('themex_google_link'); ?>" class="google" title="Google"></a><?php } ?>
					<?php if(get_option('themex_flickr_link')) { ?><a target="_blank" href="<?php echo get_option('themex_flickr_link'); ?>" class="flickr" title="Flickr"></a><?php } ?>	
					<?php if(get_option('themex_lastfm_link')) { ?><a target="_blank" href="<?php echo get_option('themex_lastfm_link'); ?>" class="lastfm" title="LastFM"></a><?php } ?>					
					<?php if(get_option('themex_youtube_link')) { ?><a target="_blank" href="<?php echo get_option('themex_youtube_link'); ?>" class="youtube" title="YouTube"></a><?php } ?>					
					<?php if(get_option('themex_facebook_link')) { ?><a target="_blank" href="<?php echo get_option('themex_facebook_link'); ?>" class="facebook" title="Facebook"></a><?php } ?>
					<?php if(get_option('themex_linkedin_link')) { ?><a target="_blank" href="<?php echo get_option('themex_linkedin_link'); ?>" class="linkedin" title="LinkedIn"></a><?php } ?>
					<?php if(get_option('themex_reverbnation_link')) { ?><a target="_blank" href="<?php echo get_option('themex_reverbnation_link'); ?>" class="reverbnation" title="ReverbNation"></a><?php } ?>
					<?php if(get_option('themex_vimeo_link')) { ?><a target="_blank" href="<?php echo get_option('themex_vimeo_link'); ?>" class="vimeo" title="Vimeo"></a><?php } ?>								
					<?php if(get_option('themex_tumblr_link')) { ?><a target="_blank" href="<?php echo get_option('themex_tumblr_link'); ?>" class="tumblr" title="Tumblr"></a><?php } ?>	
					<?php if(get_option('themex_twitter_link')) { ?><a target="_blank" href="<?php echo get_option('themex_twitter_link'); ?>" class="twitter" title="Twitter"></a><?php } ?>
				</div><!--/ social links-->				
				<div class="clear"></div>
			</div>			
		</div><!--/ supheader-->
		<div class="subheader wrapper">
			<div class="container">
				<?php wp_nav_menu( array( 'theme_location' => 'main_menu','container_class' => 'menu' ) ); ?>
				<div class="select-menu">
					<?php themex_dropdown_menu('main_menu'); ?>
					<span>&nbsp;</span>
				</div><!--/ select menu-->		
				<div class="search-form">
					<?php get_search_form(); ?>
				</div><!--/ search form-->
				<div class="clear"></div>
			</div>			
		</div><!--/ subheader-->
	</div><!--/ header-->
	<?php
	if(is_front_page()) {
		//slider
		get_template_part('module','slider');
		
		//player
		get_template_part('module','player');
	} else { ?>
	<div class="page-title wrapper">
		<div class="container">
			<?php if(wp_title('-', false)) { ?>
			<span><?php themex_page_title(); ?></span>
			<?php } ?>
			<?php if(get_option('themex_share_button')) { ?>
			<div class="button-container tip-container">
				<a href="#" class="button dark share-button">
					<span><?php _e('Share','replay'); ?></span>
					<span class="share-icon"></span>					
				</a>
				<div class="tip-cloud">
					<div class="tip-corner"></div>
					<div class="tip-content"><?php echo do_shortcode(html_entity_decode(stripslashes_deep(get_option('themex_share_button')))); ?></div>						
				</div>
			</div>
			<?php } ?>
			<div class="clear"></div>
		</div>
	</div><!--/ page title-->
	<?php } ?>
	<div class="content wrapper">
		<div class="container">