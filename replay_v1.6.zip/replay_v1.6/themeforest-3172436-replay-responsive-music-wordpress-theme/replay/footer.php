			<div class="clear"></div>
			<div class="footer-widgets">
				<?php if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Footer Sidebar') ) ?>				
			</div>			
			<div class="clear"></div>
		</div>
	</div><!--/ content-->
	<div class="footer wrapper">
		<div class="background">
			<div class="container">				
				<?php wp_nav_menu( array( 'theme_location' => 'footer_menu','container_class' => 'menu' ) ); ?>
				<div class="copyright">
					<?php 
					if(get_option('themex_copyright_text')) {
						echo html_entity_decode(get_option('themex_copyright_text'));
					} else {
						echo 'Replay Records &copy; 2012';
					}
					?>					
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div><!--/ footer-->
	<?php if(!is_user_logged_in() && get_option('users_can_register')) { ?>
	<div class="login-form">
		<div class="form-container">
			<div class="content-block">
				<div class="block-title">
					<span><?php _e('Sign In','replay'); ?></span>
					<a href="#" class="login-close-button"></a>
				</div>
				<div class="block-content">
					<form id="themex_login_form">
						<div class="alert"></div>
						<input type="text" name="themex_username" id="themex_username" value="<?php _e('username','replay'); ?>" />
						<input type="password" name="themex_password" id="themex_password" value="123456" />
						<input type="hidden" name="themex_nonce" id="themex_nonce" value="<?php echo wp_create_nonce('themex_nonce'); ?>" />
						<a href="#" class="button submit"><span><?php _e('Sign In','replay'); ?></span></a>
						<a href="<?php echo site_url('/wp-login.php?action=register'); ?>" class="button grey"><span><?php _e('Register','replay'); ?></span></a>
						<div class="formatted-form-loader"></div>	
						<div class="clear"></div>
					</form>
				</div>
			</div>
		</div>
	</div><!--/ login form-->
	<?php } ?>
<?php wp_footer(); ?>
</body>
</html>