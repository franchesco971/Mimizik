<?php
//Show all errors except notices
error_reporting(E_ALL ^ E_NOTICE);

// Define constants
define('THEME_NAME','Replay');
define('THEME_PATH',get_template_directory().'/');
define('THEME_URI',get_template_directory_uri().'/');
define('THEME_CSS_URI',get_stylesheet_directory_uri().'/');
define('THEME_VERSION','1.6');

define('THEMEX_PATH',THEME_PATH.'framework/');
define('THEMEX_URI',THEME_URI.'framework/');

//Add theme supports
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'post-thumbnails' );

//Load Textdomain
load_theme_textdomain('replay', THEME_PATH.'languages');

//Set content width
if ( ! isset( $content_width ) ) $content_width = 940;

//Register menus
register_nav_menu( 'main_menu', __('Main Menu','replay') );
register_nav_menu( 'footer_menu', __('Footer Menu','replay') );

//Include theme functions
include(THEMEX_PATH.'functions.php');

// Include theme configuration file
include(THEMEX_PATH.'config.php');

// Include core class
include(THEMEX_PATH.'classes/themex.core.php');

// Init theme
$theme=new ThemexCore($config);
?>