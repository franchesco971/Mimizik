<?php
//query audio slides
$query=new WP_Query(array(
	'post_type' =>'slide',
	'showposts' => -1,
	'meta_key' => 'slide_track_url',
	'meta_value' => '',
	'meta_compare' => '!=',
));

if($query->have_posts()) {
?>
<div class="featured-player wrapper">
	<div class="background wrapper">
		<div class="container">
			<?php 
			if(get_option('themex_player_code')) { 
				echo do_shortcode(html_entity_decode(stripslashes_deep(get_option('themex_player_code'))));
			} else {
			?>
			<div id="jp_container" class="jp-audio">
				<div class="jp-type-playlist">
					<div id="jquery_jplayer" class="jp-jplayer"></div>
					<div class="jp-gui">
						<div class="jp-interface">							
							<div class="jp-info">
								<div class="jp-title">
								<ul>
									<li></li>
								</ul>
								</div>
								<div class="jp-time">
									<div class="jp-duration"></div>
									<div>/</div>
									<div class="jp-current-time"></div>										
								</div>
								<div class="clear"></div>
								<div class="jp-progress">
									<div class="jp-seek-bar">
										<div class="jp-play-bar"></div>
									</div>
								</div>
							</div>
							<div class="jp-controls-holder">
								<ul class="jp-controls">
									<li><a href="javascript:;" class="jp-previous" tabindex="1"></a></li>
									<li><a href="javascript:;" class="jp-play" tabindex="1"></a></li>
									<li><a href="javascript:;" class="jp-pause" tabindex="1"></a></li>
									<li><a href="javascript:;" class="jp-next" tabindex="1"></a></li>
								</ul>
							</div>
							<div class="jp-volume-bar">
								<div class="jp-volume-bar-value"></div>
							</div>						
							<div class="jp-playlist">
								<ul>
									<li></li>
								</ul>																			
							</div>
						</div>
					</div>						
					<div class="jp-no-solution">
						<span><?php _e('Update Required','replay'); ?></span>
						<?php _e('To play the media you will need to update your browser to a recent version.','replay'); ?>
					</div>
				</div>
			</div>
			<div class="playlist">
				<?php
				//button flag
				while($query->have_posts()) : $query->the_post(); 
					if(!isset($button)) {
						if(get_post_meta($post->ID,'slide_track_link',true)!='') {
							$button=true;
						} else {
							$button=false;
						}
					}									
				?>
				<a href="<?php echo get_post_meta($post->ID,'slide_track_url',true); ?>" title="" data-link="<?php echo get_post_meta($post->ID,'slide_track_link',true); ?>"><?php the_title(); ?></a>
				<?php endwhile; ?>
			</div>	
			<div class="featured-player-button">
				<div class="button-container <?php if(!$button) { ?>hidden<?php } ?>">
					<a href="#" target="_blank" class="button"><span><?php _e('Download','replay'); ?></span></a>
				</div>
			</div>			
			<?php } ?>
			<div class="clear"></div>
		</div>
	</div>
	<input type="hidden" class="autoplay" value="<?php echo get_option('themex_player_autoplay'); ?>" />
</div><!--/ featured player-->
<?php } ?>