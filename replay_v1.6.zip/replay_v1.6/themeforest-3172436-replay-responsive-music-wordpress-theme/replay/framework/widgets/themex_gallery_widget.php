<?php
//Widget Name: Gallery Widget

class themex_gallery_widget extends WP_Widget {

	//Widget Setup
	function __construct() {
		//Basic settings
		$settings = array( 'classname' => 'widget-gallery', 'description' => __('Latest galleries slider.', 'replay') );

		//Controls
		$controls = array( 'width' => 300, 'height' => 300, 'id_base' => __CLASS__ );

		//Creation
		$this->WP_Widget( __CLASS__, __('Gallery','replay'), $settings, $controls );
	}

	//Widget view
	function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );
		extract( $instance, EXTR_SKIP );	
		
		//get galleries
		$galleries=themex_get_posts('gallery',array('ID','title','permalink'),$number,null,$order);				
			
		$title = empty( $instance['title'] ) ? __( 'Latest Galleries','replay' ) : $instance['title'];	
		if(count($galleries)>1) {
			$title=$title.'</span><div class="arrow carousel-slider-arrow arrow-right"></div><div class="arrow carousel-slider-arrow arrow-left"></div><span class="hidden">';		
		}
		$title = apply_filters('widget_title', $title, $instance, $this->id_base);
		
		echo $before_widget;
		echo $before_title.html_entity_decode($title).$after_title;
		?>
		<div class="fade-slider">
			<ul>
				<?php foreach($galleries as $gallery) { ?>
				<li>
					<div class="gallery-thumbnail">
						<a href="<?php echo $gallery['permalink']; ?>"><img src="<?php echo themex_thumbnail($gallery['ID'],440) ?>" class="fullwidth" alt="" /></a>
						<a class="caption" href="<?php echo get_permalink($gallery['ID']); ?>">
							<span><?php echo $gallery['title']; ?></span>
						</a>
					</div>
				</li>
				<?php } ?>
			</ul>
		</div>
		<?php
		echo $after_widget;
	}

	//Update widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = stripslashes_deep($new_instance['title']);
		$instance['number'] = intval($new_instance['number']);
		$instance['order'] = $new_instance['order'];
		return $instance;
	}
	
	//Widget form
	function form( $instance ) {
		//Defaults
		$defaults = array();
		$instance = wp_parse_args( (array)$instance, $defaults ); ?>
		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Galleries Number', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $instance['number']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('order'); ?>"><?php _e('Order By', 'replay'); ?>:</label>
			<select class="widefat" type="order" id="<?php echo $this->get_field_id( 'order' ); ?>" name="<?php echo $this->get_field_name( 'order' ); ?>">
				<option value="date" <?php if($instance['order']=='date') echo 'selected="selected"'; ?>><?php _e('Date', 'replay') ?></option>
				<option value="rand" <?php if($instance['order']=='rand') echo 'selected="selected"'; ?>><?php _e('Random', 'replay') ?></option>
			</select>
		</p>
	<?php
	}
}
?>