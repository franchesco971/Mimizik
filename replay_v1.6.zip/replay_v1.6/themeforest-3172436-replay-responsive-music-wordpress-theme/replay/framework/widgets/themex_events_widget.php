<?php
//Widget Name: Events Widget

class themex_events_widget extends WP_Widget {

	//Widget Setup
	function __construct() {
		//Basic settings
		$settings = array( 'classname' => 'widget-events', 'description' => __('Upcoming events list.', 'replay') );

		//Controls
		$controls = array( 'width' => 300, 'height' => 300, 'id_base' => __CLASS__ );

		//Creation
		$this->WP_Widget( __CLASS__, __('Events','replay'), $settings, $controls );
	}

	//Widget view
	function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );
		extract( $instance, EXTR_SKIP );
		
		$title = apply_filters('widget_title', empty( $instance['title'] ) ? __( 'Events','replay' ) : $instance['title'], $instance, $this->id_base);
		
		//get events
		$events=themex_filter_events(themex_get_posts('event',array('ID','title','artists','date','place','link','status','details'),-1));
		$events=array_slice($events,0,$number);
		
		echo $before_widget;
		echo $before_title.$title.$after_title;		
		foreach($events as $event) { 
		?>
		<div class="featured-event">
			<div class="event-date">
				<div class="event-date-holder">
					<div class="event-date-number"><?php echo substr($event['date'],0,2); ?></div>
					<div class="event-month"><?php echo date('M', $event['timestamp']); ?></div>
				</div>
				<div class="clear"></div>
			</div>
			<div class="event-details">
				<h5 class="event-title"><?php echo themex_event_title($event,'&#64;'); ?></h5>
				<div class="event-place"><?php echo $event['place']; ?></div>
				<?php if($event['status']=='active' && $event['link']) { ?>
				<a href="<?php echo $event['link']; ?>" target="_blank" class="button small"><span><?php _e('Buy Tickets','replay'); ?></span></a>
				<?php } else if($event['status']!='active') { ?>
				<span class="event-status">
				<?php
				if($event['status']=='free') {
					_e('Free Entry','replay'); 
				} else if($event['status']=='sold') {
					_e('Sold Out','replay');
				} else if($event['status']=='cancelled') { 
					_e('Cancelled','replay');
				} 
				?>	
				</span>
				<?php } ?>
			</div>
		</div>
		<?php
		}
		echo $after_widget;
	}

	//Update widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = stripslashes_deep($new_instance['title']);
		$instance['number'] = intval($new_instance['number']);
		return $instance;
	}
	
	//Widget form
	function form( $instance ) {
		//Defaults
		$defaults = array();
		$instance = wp_parse_args( (array)$instance, $defaults ); ?>
		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Events Number', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $instance['number']; ?>" />
		</p>		
	<?php
	}
}
?>