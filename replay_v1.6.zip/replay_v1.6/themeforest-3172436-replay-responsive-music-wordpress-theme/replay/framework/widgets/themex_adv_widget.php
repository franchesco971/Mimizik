<?php
//Widget Name: Gallery Widget

class themex_adv_widget extends WP_Widget {

	//Widget Setup
	function __construct() {
		//Basic settings
		$settings = array( 'classname' => 'widget-gallery', 'description' => __('Advertisement image with custom link.', 'replay') );

		//Controls
		$controls = array( 'width' => 300, 'height' => 300, 'id_base' => __CLASS__ );

		//Creation
		$this->WP_Widget( __CLASS__, __('Advertisement Image','replay'), $settings, $controls );
	}

	//Widget view
	function widget( $args, $instance ) {
		?>
		<div class="bordered-image">
			<a href="<?php echo $instance['link']; ?>" target="_blank"><img src="<?php echo $instance['image']; ?>" class="fullwidth" alt="" /></a>
		</div>
		<?php
	}

	//Update widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['link'] = $new_instance['link'];
		$instance['image'] = $new_instance['image'];
		return $instance;
	}
	
	//Widget form
	function form( $instance ) {
		//Defaults
		$defaults = array();
		$instance = wp_parse_args( (array)$instance, $defaults ); ?>
		<p>
			<label for="<?php echo $this->get_field_id('image'); ?>"><?php _e('Image URL', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'image' ); ?>" name="<?php echo $this->get_field_name( 'image' ); ?>" value="<?php echo $instance['image']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('link'); ?>"><?php _e('Image Link', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'link' ); ?>" name="<?php echo $this->get_field_name( 'link' ); ?>" value="<?php echo $instance['link']; ?>" />
		</p>
	<?php
	}
}
?>