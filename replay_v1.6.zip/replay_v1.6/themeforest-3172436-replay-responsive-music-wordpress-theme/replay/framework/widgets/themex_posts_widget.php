<?php
//Widget Name: Posts Widget

class themex_posts_widget extends WP_Widget {

	//Widget Setup
	function __construct() {
		//Basic settings
		$settings = array( 'classname' => 'widget-selected-posts', 'description' => __('Posts from selected category.', 'replay') );

		//Controls
		$controls = array( 'width' => 300, 'height' => 300, 'id_base' => __CLASS__ );

		//Creation
		$this->WP_Widget( __CLASS__, __('Selected Posts','replay'), $settings, $controls );
	}

	//Widget view
	function widget( $args, $instance ) {
		extract( $args );
		
		if($instance['number']=='') {
			$instance['number']='3';
		}
		
		$title = empty( $instance['title'] ) ? __( 'Latest Posts','replay' ) : $instance['title'];
		$title = apply_filters('widget_title', $title, $instance, $this->id_base);
		
		//posts query
		$query = new WP_Query(array(
					'post_type' => 'post',
					'orderby' => $instance['order'],
					'showposts' => $instance['number'],
					'cat' => $instance['category']
				));
		
		echo $before_widget;
		echo $before_title.$title.$after_title;			
		if ($query->have_posts()) : while ( $query->have_posts() ) : $query->the_post(); ?>
			<div class="featured-post">
				<h5 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
				<div class="post-info"><?php themex_time(); ?> <?php if(comments_open()) { ?>| <a href="<?php comments_link(); ?>"><?php comments_number( '0 '.__('Comments','replay'), '1 '.__('Comment','replay'), '% '.__('Comments','replay') ); ?></a><?php } ?></div>
			</div>
		<?php
		endwhile; endif;
		echo $after_widget;
	}

	//Update widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['order'] = $new_instance['order'];
		$instance['category'] = $new_instance['category'];
		$instance['number'] = intval($new_instance['number']);
		return $instance;
	}
	
	//Widget form
	function form( $instance ) {
		//Defaults
		$defaults = array();
		$instance = wp_parse_args( (array)$instance, $defaults ); ?>
		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Posts Number', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $instance['number']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php _e('Posts Category:', 'replay') ?></label>
			<?php
			$args = array(
				'show_option_all'   => __('All Categories', 'replay'),
				'hide_empty'         => 0, 
				'echo'               => 0,
				'selected'           => $instance['category'],
				'hierarchical'       => 0, 
				'id'				 => $this->get_field_id( 'category' ),
				'name'               => $this->get_field_name( 'category' ),
				'class'              => 'widefat',
				'depth'              => 0,
				'tab_index'          => 0,
				'taxonomy'           => 'category',
				'hide_if_empty'      => false 	
			);	
			echo wp_dropdown_categories( $args );
			?>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('order'); ?>"><?php _e('Order By', 'replay'); ?>:</label>
			<select class="widefat" type="order" id="<?php echo $this->get_field_id( 'order' ); ?>" name="<?php echo $this->get_field_name( 'order' ); ?>">
				<option value="date" <?php if($instance['order']=='date') echo 'selected="selected"'; ?>><?php _e('Date', 'replay') ?></option>
				<option value="rand" <?php if($instance['order']=='rand') echo 'selected="selected"'; ?>><?php _e('Random', 'replay') ?></option>
				<option value="comment_count" <?php if($instance['order']=='comment_count') echo 'selected="selected"'; ?>><?php _e('Comments', 'replay') ?></option>
			</select>
		</p>
	<?php
	}
}
?>