<?php
//Widget Name: Social Widget

class themex_social_widget extends WP_Widget {

	//Widget Setup
	function __construct() {
		//Basic settings
		$settings = array( 'classname' => 'widget-social', 'description' => __('Updates from the social networks.', 'replay') );

		//Controls
		$controls = array( 'width' => 300, 'height' => 300, 'id_base' => __CLASS__ );

		//Creation
		$this->WP_Widget( __CLASS__, __('Social Media','replay'), $settings, $controls );
	}

	//Widget view
	function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );
		extract( $instance, EXTR_SKIP );
		
		$tabs=array();
		if($facebook_link!='') {
			$tabs['Facebook']=$instance['facebook_position'];
		}
		if($twitter_username!='') {
			$tabs['Twitter']=$instance['twitter_position'];
		}
		if($youtube_username!='') {
			$tabs['YouTube']=$instance['youtube_position'];
		}
		if($soundcloud_code!='') {
			$tabs['SoundCloud']=$instance['soundcloud_position'];
		}	
		asort($tabs);
		
		$title = apply_filters('widget_title', empty( $instance['title'] ) ? __( 'Social Media','replay' ) : $instance['title'], $instance, $this->id_base);
		
		echo $before_widget;
		echo $before_title.$title.$after_title;		
		?>
		<div class="social-widget tabs-container">
			<div class="tabs">
				<ul>					
					<?php foreach($tabs as $key=>$tab) { ?>
					<li><a class="<?php echo strtolower($key); ?>" title="<?php echo $key; ?>" href="#"></a></li>
					<?php } ?>
				</ul>
			</div>	
			<div class="clear"></div>
			<div class="panes">
				<?php 
				foreach($tabs as $key=>$tab) {
					$key=strtolower($key);
					if($key=='facebook') {
					?>
					<div class="pane facebook">
						<div id="fb-root"></div>
						<script>(function(d, s, id) {
						  var js, fjs = d.getElementsByTagName(s)[0];
						  if (d.getElementById(id)) return;
						  js = d.createElement(s); js.id = id;
						  js.src = "http://connect.facebook.net/<?php echo get_locale(); ?>/all.js#xfbml=1";
						  fjs.parentNode.insertBefore(js, fjs);
						}(document, 'script', 'facebook-jssdk'));</script>
						<div class="fb-like-box" data-href="<?php echo $facebook_link; ?>" data-mobile="false" data-width="260" data-show-faces="true" data-border-color="#fff" data-stream="false" data-header="false"></div>
					</div>
					<?php } else if($key=='twitter') { ?>
					<div class="pane twitter">
						<input type="hidden" class="twitter-username" value="<?php echo $twitter_username; ?>" />
						<input type="hidden" class="tweets-number" value="<?php echo $tweets_number; ?>" />
					</div>
					<?php } else if($key=='youtube') { ?>
					<div class="pane youtube">
						<iframe id="fr" src="http://www.youtube.com/subscribe_widget?p=<?php echo $youtube_username; ?>" style="overflow: hidden; height: 105px; width: 100%; border: 0;"></iframe>
					</div>
					<?php } else if($key=='soundcloud') { ?>
					<div class="pane soundcloud">
						<?php echo $soundcloud_code; ?>
					</div>
					<?php
					}
				}
				?>
			</div>
		</div>
		<?php
		echo $after_widget;
	}

	//Update widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = stripslashes_deep($new_instance['title']);
		$instance['twitter_username'] = stripslashes_deep($new_instance['twitter_username']);
		$instance['tweets_number'] = intval($new_instance['tweets_number']);
		$instance['facebook_link'] = stripslashes_deep($new_instance['facebook_link']);
		$instance['youtube_username'] = stripslashes_deep($new_instance['youtube_username']);
		$instance['soundcloud_code'] = stripslashes_deep($new_instance['soundcloud_code']);
		$instance['facebook_position'] = intval($new_instance['facebook_position']);
		$instance['twitter_position'] = intval($new_instance['twitter_position']);
		$instance['youtube_position'] = intval($new_instance['youtube_position']);
		$instance['soundcloud_position'] = intval($new_instance['soundcloud_position']);
		return $instance;
	}
	
	//Widget form
	function form( $instance ) {
		//Defaults
		$defaults = array(
			'facebook_position'=>'1',
			'twitter_position'=>'2',
			'youtube_position'=>'3',
			'soundcloud_position'=>'4',
			'tweets_number' => '3',
		);
		$instance = wp_parse_args( (array)$instance, $defaults ); ?>
		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('facebook Link'); ?>"><?php _e('Facebook Link', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'facebook_link' ); ?>" name="<?php echo $this->get_field_name( 'facebook_link' ); ?>" value="<?php echo $instance['facebook_link']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('twitter_username'); ?>"><?php _e('Twitter Username', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'twitter_username' ); ?>" name="<?php echo $this->get_field_name( 'twitter_username' ); ?>" value="<?php echo $instance['twitter_username']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('tweets_number'); ?>"><?php _e('Tweets Number', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'tweets_number' ); ?>" name="<?php echo $this->get_field_name( 'tweets_number' ); ?>" value="<?php echo $instance['tweets_number']; ?>" />
		</p>		
		<p>
			<label for="<?php echo $this->get_field_id('youtube_username'); ?>"><?php _e('YouTube Username', 'replay'); ?>:</label>
			<input class="widefat" type="text" id="<?php echo $this->get_field_id( 'youtube_username' ); ?>" name="<?php echo $this->get_field_name( 'youtube_username' ); ?>" value="<?php echo $instance['youtube_username']; ?>" />
		</p>		
		<p>
			<label for="<?php echo $this->get_field_id('soundcloud_code'); ?>"><?php _e('SoundCloud Code', 'replay'); ?>:</label>
			<textarea class="widefat" id="<?php echo $this->get_field_id( 'soundcloud_code' ); ?>" name="<?php echo $this->get_field_name( 'soundcloud_code' ); ?>"><?php echo $instance['soundcloud_code']; ?></textarea>
		</p>		
		<p>
			<label for="<?php echo $this->get_field_id('facebook_position'); ?>"><?php _e('Facebook Tab Position', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'facebook_position' ); ?>" name="<?php echo $this->get_field_name( 'facebook_position' ); ?>" value="<?php echo $instance['facebook_position']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('twitter_position'); ?>"><?php _e('Twitter Tab Position', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'twitter_position' ); ?>" name="<?php echo $this->get_field_name( 'twitter_position' ); ?>" value="<?php echo $instance['twitter_position']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('youtube_position'); ?>"><?php _e('Youtube Tab Position', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'youtube_position' ); ?>" name="<?php echo $this->get_field_name( 'youtube_position' ); ?>" value="<?php echo $instance['youtube_position']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('soundcloud_position'); ?>"><?php _e('SoundCloud Tab Position', 'replay'); ?>:</label>
			<input class="widefat" type="number" id="<?php echo $this->get_field_id( 'soundcloud_position' ); ?>" name="<?php echo $this->get_field_name( 'soundcloud_position' ); ?>" value="<?php echo $instance['soundcloud_position']; ?>" />
		</p>
	<?php
	}
}
?>