<?php
//Custom form module
class ThemexForm {

	public static $data;
	public static $id=__CLASS__;
	
	//Init module
	public static function init() {
		
		//actions for contact form
		add_action('wp_ajax_themex_form', array(__CLASS__,'processData'));
		add_action('wp_ajax_nopriv_themex_form', array(__CLASS__,'processData'));
	
	}

	//Refresh module stored data
	public static function refresh() {
		self::$data=ThemexCore::getOption(self::$id);
	}
	
	//Change module stored data
	public static function change() {
	
		//refresh stored data
		self::refresh();
		
		//set action type
		$type=$_POST['type'];
		
		//choose method
		if($type=='add_field') {
			self::addField();
		} else if($type=='remove_field') {
			self::removeField($_POST['field_id']);
		}
		
	}
	
	//Save module static data
	public static function save() {
		ThemexCore::updateOption(self::$id,self::$data);
	}
	
	//Save module settings
	public static function saveSettings($data) {
	
		//refresh stored data
		self::refresh();
		
		//search for widget areas options
		foreach($data as $key=>$value) {		
			if($key==self::$id) {				
				self::$data=$value;
			}
		}	
		
		//save static data
		self::save();
	}
	
	//Render module settings
	public static function renderSettings() {
	
		//get module stored data
		self::refresh();
		
		$out='<div class="themex_form">';
		
		//success message option
		$out.=ThemexInterface::renderOption(array(
				'type' => 'textarea',
				'id' => self::$id.'[message]',
				'name' => __('Success Message','replay'),
				'default' => isset(self::$data['message'])?self::$data['message']:'',
			)
		);
		
		//captcha option
		$out.=ThemexInterface::renderOption(array(
					'type' => 'checkbox',
					'id' => self::$id.'[captcha]',
					'default' => isset(self::$data['captcha'])?self::$data['captcha']:'',
					'name' => __('Enable Captcha Protection','replay')
				)
		);
		
		//settings for stored fields
		if(is_array(self::$data['fields'])) {
		
			foreach(self::$data['fields'] as $field_id=>$field) {
			
				$out.='<div class="themex_section" id="'.$field_id.'">';
				
				//field type
				$out.=ThemexInterface::renderOption(array(
						'type' => 'select',
						'name' => __('Field Type','replay'),
						'id' => self::$id.'[fields]['.$field_id.'][type]',
						'default' => self::$data['fields'][$field_id]['type'],
						'options' => array('message'=>__('Message','replay'),'text'=>__('Text','replay'),'number'=>__('Number','replay'),'email'=>__('Email','replay'),'select'=>__('Select','replay'))
					)
				);
				
				//field label
				$out.=ThemexInterface::renderOption(array(
						'type' => 'text',
						'name' => __('Field Label','replay'),
						'id' => self::$id.'[fields]['.$field_id.'][label]',
						'default' => self::$data['fields'][$field_id]['label']
					)
				);	
				
				//field options
				$out.=ThemexInterface::renderOption(array(
						'type' => 'text',
						'description' => __('Enter in comma separated options.','replay'),
						'id' => self::$id.'[fields]['.$field_id.'][options]',
						'default' => self::$data['fields'][$field_id]['options'],
						'hidden' => true,
						'name' => __('Field Options','replay')
					)
				);	
				
				//actions
				$out.='<div class="themex_icon add_field"></div><div class="themex_icon remove_field"></div>';
				
				//close section
				$out.='</div>';
			
			}
			
		//default settings
		} else {
		
			//generate field id
			$field_id=uniqid();
			
			$out.='<div class="themex_section" id="'.$field_id.'">';
		
			//field type
			$out.=ThemexInterface::renderOption(array(
						'type' => 'select',
						'name' => __('Field Type','replay'),
						'id' => self::$id.'[fields]['.$field_id.'][type]',
						'std' => '',
						'options' => array('message'=>__('Message','replay'),'text'=>__('Text','replay'),'number'=>__('Number','replay'),'email'=>__('Email','replay'),'select'=>__('Select','replay'))						
					)
				);
			
			//field label
			$out.=ThemexInterface::renderOption(array(
						'type' => 'text',
						'id' => self::$id.'[fields]['.$field_id.'][label]',
						'name' => __('Field Label','replay'),
					)
				);
				
			//field options
			$out.=ThemexInterface::renderOption(array(
					'type' => 'text',
					'id' => self::$id.'[fields]['.$field_id.'][options]',
					'description' => __('Enter in comma separated options.','replay'),
					'default' => '',
					'hidden' => true,
					'name' => __('Field Options','replay')
				)
			);
				
			//actions
			$out.='<div class="themex_icon add_field"></div><div class="themex_icon remove_field"></div>';
				
			//close section
			$out.='</div>';
			
			//save defaults
			$data['message']='';
			self::$data['fields'][$field_id]=array(
				'type' => 'text',
				'label' => '',
				'options' => '',
			);			
			
			self::save();
				
		}	

		$out.='</div>';
		
		return $out;
		
	}
	
	public static function renderData() { 
	
		//refresh stored settings
		self::refresh();
		
		//enqueue script
		wp_enqueue_script( 'themex_form', THEMEX_URI.'extensions/themex-form/form.js' );
		
		$out='<div class="contact-form formatted-form"><div id="themex_form_message"></div><form name="themex_form" id="themex_form">';
		
		//render each form field
		if(is_array(self::$data['fields'])) {
			$index=0;
			foreach(self::$data['fields'] as $field_id=>$field) {
				
				switch($field['type']) {
				
					case 'message':
						$option['type']='textarea';			
					break;
					
					case 'select':
						$option['type']='select';					
						$option['options']=explode(',', $field['options']);	
					break;
					
					default:
						$option['type']='text';
					break;
					
				}
				
				$option['attributes']=array( 'data-validation' => $field['type'] );
				$option['id']=$field_id;
				$option['default']=$field['label'];
				
				if($field['type']!='message') {
					$out.='<div class="one-half column ';
					if(($index+1) % 2==0) {
						$out.='last';
					}
					$out.='">';
				}
				
				$out.='<div class="field-wrapper">'.ThemexInterface::renderOption($option, true).'</div>';
				
				if($field['type']!='message') {
					$out.='</div>';
				}
				
				$index++;
			}
		}
		
		if(isset(self::$data['captcha']) && self::$data['captcha']=='true') {
			$out.='<div class="captcha" id="themex_form_captcha">';			
			$out.='<img src="'.THEMEX_URI.'extensions/themex-form/captcha.php" alt="" />';
			$out.='<input name="themex_form_captcha" type="text" id="themex_form_captcha" size="6" value="" />';
			$out.='</div>';
		}
		
		$out.='<div class="clear"></div><div class="submit button"><span>'.__('Send Message','replay').'</span></div><div class="formatted-form-loader"></div></form></div>';
		
		echo $out;
	
	}
	
	//Process user data
	public static function processData() {
	
		//refresh stored settings
		self::refresh();
	
		parse_str($_POST['data'], $data);
	
		//get captcha
		session_start();
		$posted_code=md5($data['themex_form_captcha']);
		$session_code = $_SESSION['captcha'];
		
		//check errors
		if($session_code != $posted_code && self::$data['captcha']=='true') {
			$errors.='<li>'.__('The verification code you entered is incorrect','replay').'.</li>';
		}
		
		if(is_array(self::$data['fields'])) {
			foreach(self::$data['fields'] as $field_id=>$field) {
				$value=$data[$field_id];
				if(trim($value)=='') {
					$errors.='<li>"'.$field['label'].'" '.__('field is required','replay').'</li>';
				}
				if($field['type']=='number' && !is_numeric($value) && $value!='') {
					$errors.='<li>"'.$field['label'].'" '.__('field can only contain numbers','replay').'.</li>';
				}
				if($field['type']=='email' && !preg_match("/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/",$value) && $value!='') {
					$errors.='<li>'.__('You have entered an invalid email address','replay').'.</li>';
				}
			}
		}
		
		//errors response
		if($errors != '') { 
			echo '<div class="alert-box"><ul class="error">'.$errors.'</ul></div>';		
		//send email
		} else {
			if (!defined('PHP_EOL')) {
				define('PHP_EOL', '\r\n');
			}

			//receiver address
			$address=get_option('admin_email');
			
			//email headers
			$headers .= "MIME-Version: 1.0" . PHP_EOL;
			$headers .= "Content-type: text/plain; charset=utf-8" . PHP_EOL;
			$headers .= "Content-Transfer-Encoding: quoted-printable" . PHP_EOL;
			
			//message
			$message='';			
			if(is_array(self::$data['fields'])) {
				foreach(self::$data['fields'] as $field_id=>$field) {
					$message.=self::$data['fields'][$field_id]['label'].': '.$data[$field_id].PHP_EOL;		
				}
			}
			
			if(mail($address, __('Feedback','replay'), $message, $headers)) {
				echo '<div class="alert-box"><ul class="success"><li>'.self::$data['message'].'</li></ul></div>';
			}
		}		
		
		die();
		
	}
	
	//Add form field
	public static function addField() {
		
		//generate field id
		$field_id=uniqid();
		
		self::$data['fields'][$field_id]=array();	
		
		//save static data
		self::save();
				
		//server response
		$out='<div class="themex_section hidden" id="'.$field_id.'">';
	
		//field type
		$out.=ThemexInterface::renderOption(array(
					'type' => 'select',
					'id' => self::$id.'[fields]['.$field_id.'][type]',
					'std' => self::$data['fields'][$field_id]['type'],
					'name' => __('Field Type','replay'),
					'options' => array('message'=>'Message','text'=>'Text','number'=>'Number','email'=>'Email','select'=>'Select')
				)
			);
		
		//field label
		$out.=ThemexInterface::renderOption(array(
					'type' => 'text',
					'id' => self::$id.'[fields]['.$field_id.'][label]',
					'name' => __('Field Label','replay')
				)
			);
			
		//field options
		$out.=ThemexInterface::renderOption(array(
				'type' => 'text',
				'id' => self::$id.'[fields]['.$field_id.'][options]',
				'default' => self::$data['fields'][$field_id]['options'],
				'parent' => array(self::$id.'['.$field_id.'][type]','email'),
				'description' => __('Enter in comma separated options.','replay'),
				'name' => __('Field Options','replay')			
			)
		);
			
		//action buttons
		$out.='<div class="themex_icon remove_field"></div><div class="themex_icon add_field"></div>';
			
		//close section
		$out.='</div>';			

		echo $out;
		
	}
	
	//Remove form field
	public static function removeField($field_id) {
		
		if(count(self::$data['fields'])>1) {

			//unset current field
			unset(self::$data['fields'][$field_id]);
			
		}
		
		//save fields
		self::save();
		
	}
	
}
?>