<?php
//Custom styler module
class ThemexStyler {

	public static $data;
	public static $id=__CLASS__;
	
	//Init module
	public static function init() {
	
		self::$data=ThemexCore::$components['custom_styles'];
		
		//add custom scripts action
		add_action('wp_head', array(__CLASS__,'renderData'));
	
	}
	
	//Apply custom styles
	public static function renderData() {
	
		global $post;
	
		//favicon
		$out='<link rel="shortcut icon" href="'.ThemexCore::getOption('favicon',THEME_URI.'framework/admin/images/favicon.ico').'" />';
		
		//styles
		$out.='<style type="text/css">'.ThemexCore::getOption('css');
		
		if(is_array(self::$data)) {
			
			foreach(self::$data as $style) {
				$out.=$style['elements'].'{';
				
				if(is_array($style['attributes'])) {
					foreach($style['attributes'] as $attr_name=>$option_id) {					
						if(ThemexCore::getOption($option_id)) {
						
							if($attr_name=='background-image') {
								$option='url('.ThemexCore::getOption($option_id).')';
							} else if($attr_name=='font-size') {
								$option=ThemexCore::getOption($option_id).'px';
							} else if($attr_name=='font-family') {
								$option=ThemexCore::getOption($option_id).', Arial, Helvetica, sans-serif';
							} else {
								$option=ThemexCore::getOption($option_id);
							}
							
							$out.=$attr_name.':'.$option.';';
						}						
					}
				}
				
				
				
				$out.='}';
			}
		}
		
		$out.='</style>';
		
		//fonts
		$fonts=array('"Oswald:400,700"','"Open Sans"');
		
		$out.='<script type="text/javascript">
		WebFontConfig = {google: { families: [ '.implode($fonts,',').' ] } };
		(function() {
			var wf = document.createElement("script");
			wf.src = ("https:" == document.location.protocol ? "https" : "http") + "://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js";
			wf.type = "text/javascript";
			wf.async = "true";
			var s = document.getElementsByTagName("script")[0];
			s.parentNode.insertBefore(wf, s);
		})();
		</script>';
		
		echo $out;
	}
	
}
?>