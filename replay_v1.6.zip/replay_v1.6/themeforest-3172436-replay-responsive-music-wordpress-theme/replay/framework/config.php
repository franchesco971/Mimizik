<?php
//Theme configuration
$config = array (

	//Modules
	'modules' => array(
	
		//base modules
		'interface' => 'ThemexInterface',
		
		//additional
		'themex_widgetiser' => 'ThemexWidgetiser',
		'themex_form' => 'ThemexForm',
		'themex_shortcoder' => 'ThemexShortcoder',
		'themex_styler' => 'ThemexStyler',
	),

	//Components
	'components' => array(
	
		//Theme info URI
		'theme_info' => 'http://themextemplates.com/demo/replay/updates/info.json',

		//Theme backend styles
		'backend_styles' => array (
								
			//admin panel style
			array(	'name' => 'themex_admin',
					'uri' => THEMEX_URI.'admin/css/style.css'),
		
			//color picker
			array(	'name' => 'themex_colorpicker',
					'uri' => THEMEX_URI.'admin/css/colorpicker.css'),
					
			//date picker
			array(	'name' => 'jquery-ui-datepicker',
					'uri' => THEMEX_URI.'admin/css/datepicker.css'),
					
			//thickbox
			array(	'name' => 'thickbox' ),

		),
		
		//Theme frontend styles
		'frontend_styles' => array (
			//main style
			array(	'name' => 'main',
					'uri' => THEME_CSS_URI.'style.css'),			
			
		),
		
		//Theme backend scripts
		'backend_scripts' => array (
		
			//thickbox
			array(	'name' => 'thickbox' ),
			
			//media upload
			array(	'name' => 'media-upload' ),
			
			//jquery slider
			array(	'name' => 'jquery-ui-slider' ),
			
			//jquery datepicker
			array(	'name' => 'jquery-ui-datepicker' ),
		
			//panel interface
			array(	'name' => 'themex_admin',
					'uri' => THEMEX_URI.'admin/js/jquery.interface.js',
					'deps' => array('jquery')),
					
			//color picker
			array(	'name' => 'themex_colorpicker',
					'uri' => THEMEX_URI.'admin/js/jquery.colorpicker.js',
					'deps' => array('jquery')),
					
			//shortcodes popup
			array(	'name' => 'themex_shortcode_popup',
					'uri' => THEMEX_URI.'extensions/themex-shortcoder/js/popup.js',
					'deps' => array('jquery')),
					
			//shortcodes preview
			array(	'name' => 'themex_livequery',
					'uri' => THEMEX_URI.'extensions/themex-shortcoder/js/jquery.livequery.js',
					'deps' => array('jquery')),
					
			//shortcodes cloner
			array(	'name' => 'themex_appendo',
				'uri' => THEMEX_URI.'extensions/themex-shortcoder/js/jquery.appendo.js',
				'deps' => array('jquery')),
							
			
		),	
		
		//Theme frontend scripts
		'frontend_scripts' => array (
		
			//jquery
			array(	'name' => 'jquery' ),
			
			//jquery ui core
			array(	'name' => 'jquery-ui-core',
			'condition' => array('function'=>'themex_is_slider_page','value'=>'')),
			
			//jquery ui widget
			array(	'name' => 'jquery-ui-widget',
			'condition' => array('function'=>'themex_is_slider_page','value'=>'')),
			
			//jquery ui mouse
			array(	'name' => 'jquery-ui-mouse',
			'condition' => array('function'=>'themex_is_slider_page','value'=>'')),			
			
			//jquery ui draggable
			array(	'name' => 'jquery-ui-draggable',
			'condition' => array('function'=>'themex_is_slider_page','value'=>'')),	

			//comment reply
			array(	'name' => 'comment-reply',
			'condition' => array('function'=>'themex_is_post_type','value'=>array('post'))),
			
			//main theme script
			array(	'name' => 'mainScript',
					'uri' => THEME_URI.'js/jquery.custom.js'),
					
			//fade slider
			array(	'name' => 'fadeSlider',
					'uri' => THEME_URI.'js/jquery.fadeSlider.js'),
					
			//ribbon slider
			array(	'name' => 'ribbonSlider',
					'uri' => THEME_URI.'js/jquery.ribbonSlider.js',
					'condition' => array('function'=>'themex_is_slider_page','value'=>'')),
					
			//easy slider
			array(	'name' => 'easySlider',
					'uri' => THEME_URI.'js/jquery.easySlider.js',
					'condition' => array('function'=>'is_single','value'=>'')),
					
			//mouse wheel
			array(	'name' => 'mouseWheel',
					'uri' => THEME_URI.'js/jquery.mousewheel.min.js',
					'condition' => array('function'=>'themex_is_slider_page','value'=>'')),
					
			//draggable
			array(	'name' => 'touchPunch',
					'uri' => THEME_URI.'js/jquery.ui.touchPunch.min.js',
					'condition' => array('function'=>'themex_is_slider_page','value'=>'')),
					
			//jplayer
			array(	'name' => 'jPlayer',
					'uri' => THEME_URI.'js/jplayer/jquery.jplayer.min.js',
					'condition' => array('function'=>'is_front_page','value'=>'')),
					
			//jplaylist
			array(	'name' => 'jPlaylist',
					'uri' => THEME_URI.'js/jplayer/jquery.jplayer.playlist.min.js',
					'condition' => array('function'=>'is_front_page','value'=>'')),
					
			//audiojs
			array(	'name' => 'audioJS',
					'uri' => THEME_URI.'js/audiojs/audio.min.js',
					'condition' => array('function'=>'themex_is_post_type','value'=>array('release'))),
					
			//hover script
			array(	'name' => 'hoverIntent',
					'uri' => THEME_URI.'js/jquery.hoverIntent.min.js'),
					
		),	
		
		//User Roles
		'user_roles' => array (
		),
		
		//Default widget areas
		'widget_areas' => array (
			array(	'name' => 'Footer Sidebar',
					'before_widget' => '<div class="one-third column"><div class="content-block widget %2$s">',
					'after_widget' => '</div></div></div>',
					'before_title' => '',
					'after_title' => '<div class="block-content">',
					'id' => 'footer_sidebar'),
			array(	'name' => 'Artist Sidebar',
					'before_widget' => '<div class="content-block widget %2$s">',
					'after_widget' => '</div></div>',
					'before_title' => '',
					'after_title' => '<div class="block-content">',
					'id' => 'artists_sidebar'),
		),
		
		//Widgets
		'widgets' => array ('themex_social_widget', 'themex_subscribe_widget', 'themex_events_widget', 'themex_videos_widget', 'themex_gallery_widget', 'themex_posts_widget', 'themex_adv_widget'),
		
		//Post types
		'post_types' => array (
			
			//Artist
			array (
				'id' => 'artist',
				'labels' => array (
					'name' => __('Artists','replay'),
					'singular_name' => __( 'Artist','replay' ),
					'add_new' => __('Add New','replay'),
					'add_new_item' => __('Add New Artist','replay'),
					'edit_item' => __('Edit Artist','replay'),
					'new_item' => __('New Artist','replay'),
					'view_item' => __('View Artist','replay'),
					'search_items' => __('Search Artists','replay'),
					'not_found' =>  __('No Artists Found','replay'),
					'not_found_in_trash' => __('No Artists Found in Trash','replay'), 
					'parent_item_colon' => ''
				),
				'public' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'show_ui' => true, 
				'query_var' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => null,
				'supports' => array('title','editor','thumbnail'),		
			),
			
			//Release
			array (
				'id' => 'release',
				'labels' => array (
					'name' => __('Releases','replay'),
					'singular_name' => __( 'Release','replay' ),
					'add_new' => __('Add New','replay'),
					'add_new_item' => __('Add New Release','replay'),
					'edit_item' => __('Edit Release','replay'),
					'new_item' => __('New Release','replay'),
					'view_item' => __('View Release','replay'),
					'search_items' => __('Search Releases','replay'),
					'not_found' =>  __('No Releases Found','replay'),
					'not_found_in_trash' => __('No Releases Found in Trash','replay'), 
					'parent_item_colon' => ''
				 ),
				'public' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'show_ui' => true, 
				'query_var' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => null,
				'supports' => array('title','editor','thumbnail'),
			),
			
			//Video
			array (
				'id' => 'video',
				'labels' => array (
					'name' => __('Videos','replay'),
					'singular_name' => __( 'Video','replay' ),
					'add_new' => __('Add New','replay'),
					'add_new_item' => __('Add New Video','replay'),
					'edit_item' => __('Edit Video','replay'),
					'new_item' => __('New Video','replay'),
					'view_item' => __('View Video','replay'),
					'search_items' => __('Search Videos','replay'),
					'not_found' =>  __('No Videos Found','replay'),
					'not_found_in_trash' => __('No Videos Found in Trash','replay'), 
					'parent_item_colon' => ''
				 ),
				'public' => true,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true, 
				'query_var' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => null,
				'supports' => array('title','thumbnail'),
			),
			
			//Gallery
			array (
				'id' => 'gallery',
				'labels' => array (
					'name' => __('Galleries','replay'),
					'singular_name' => __( 'Gallery','replay' ),
					'add_new' => __('Add New','replay'),
					'add_new_item' => __('Add New Gallery','replay'),
					'edit_item' => __('Edit Gallery','replay'),
					'new_item' => __('New Gallery','replay'),
					'view_item' => __('View Gallery','replay'),
					'search_items' => __('Search Galleries','replay'),
					'not_found' =>  __('No Galleries Found','replay'),
					'not_found_in_trash' => __('No Galleries Found in Trash','replay'), 
					'parent_item_colon' => ''
				 ),
				'public' => true,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true, 
				'query_var' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => null,
				'supports' => array('title','thumbnail'),	
			),
			
			//Event
			array (
				'id' => 'event',
				'labels' => array (
					'name' => __('Events','replay'),
					'singular_name' => __( 'Event','replay' ),
					'add_new' => __('Add New','replay'),
					'add_new_item' => __('Add New Event','replay'),
					'edit_item' => __('Edit Event','replay'),
					'new_item' => __('New Event','replay'),
					'view_item' => __('View Event','replay'),
					'search_items' => __('Search Events','replay'),
					'not_found' =>  __('No Events Found','replay'),
					'not_found_in_trash' => __('No Events Found in Trash','replay'), 
					'parent_item_colon' => ''
				 ),
				'public' => true,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true, 
				'query_var' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => null,
				'supports' => array('title'),
			),
			
			//Slide
			array (
				'id' => 'slide',
				'labels' => array (
					'name' => __('Slides','replay'),
					'singular_name' => __( 'Slide','replay' ),
					'add_new' => __('Add New','replay'),
					'add_new_item' => __('Add New Slide','replay'),
					'edit_item' => __('Edit Slide','replay'),
					'new_item' => __('New Slide','replay'),
					'view_item' => __('View Slide','replay'),
					'search_items' => __('Search Slides','replay'),
					'not_found' =>  __('No Slides Found','replay'),
					'not_found_in_trash' => __('No Slides Found in Trash','replay'), 
					'parent_item_colon' => ''
				 ),
				'public' => true,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true, 
				'query_var' => true,
				'capability_type' => 'post',
				'hierarchical' => false,
				'menu_position' => null,
				'supports' => array('title','editor','thumbnail'),				
			),						
		),		
		
		//Taxonomies
		'taxonomies' => array (
			array(	'taxonomy' => 'release_category',				
					'object_type' => array('release'),
					'settings' => array(
						'hierarchical' => true,
						'label' => __( 'Categories', 'replay' ),
						'singular_label' => __( 'Category', 'replay' ),
						'rewrite' => array(
							'slug' => 'release_category',
							'hierarchical' => true
						)
					)
				),
			array(	'taxonomy' => 'artist_category',				
					'object_type' => array('artist'),
					'settings' => array(
						'hierarchical' => true,
						'label' => __( 'Categories', 'replay' ),
						'singular_label' => __( 'Category', 'replay' ),
						'rewrite' => array(
							'slug' => 'artist_category',
							'hierarchical' => true
						)
					)
				),	
			array(	'taxonomy' => 'event_category',			
					'object_type' => array('event'),
					'settings' => array(
						'hierarchical' => true,
						'label' => __( 'Categories', 'replay' ),
						'singular_label' => __( 'Category', 'replay' ),
						'rewrite' => array(
							'slug' => 'event_category',
							'hierarchical' => true
						)
					)
				),	
			array(	'taxonomy' => 'gallery_category',				
					'object_type' => array('gallery'),
					'settings' => array(
						'hierarchical' => true,
						'label' => __( 'Categories', 'replay' ),
						'singular_label' => __( 'Category', 'replay' ),
						'rewrite' => array(
							'slug' => 'gallery_category',
							'hierarchical' => true
						)
					)
				),
			array(	'taxonomy' => 'video_category',				
					'object_type' => array('video'),
					'settings' => array(
						'hierarchical' => true,
						'label' => __( 'Categories', 'replay' ),
						'singular_label' => __( 'Category', 'replay' ),
						'rewrite' => array(
							'slug' => 'video_category',
							'hierarchical' => true
						)
					)
				),
		),
		
		//Meta boxes
		'meta_boxes' => array(
		
			//Page
			array(
				'id' => 'page_metabox',
				'title' =>  __('Page Options', 'replay'),
				'page' => 'page',
				'context' => 'normal',
				'priority' => 'high',
				'options' => array(	
					array(	'name' => __('Blog Category','replay'),
							'id' => 'blog_category',
							'type' => 'select_category',
							'attributes' => array('class'=>'template-blog-child child-option hidden'),
							'taxonomy' => 'category'),
					array(	'name' => __('Artists Category','replay'),
							'id' => 'artists_category',
							'type' => 'select_category',
							'attributes' => array('class'=>'template-artists-child child-option hidden'),
							'taxonomy' => 'artist_category'),
					array(	'name' => __('Events Category','replay'),
							'id' => 'events_category',
							'type' => 'select_category',
							'attributes' => array('class'=>'template-events-child child-option hidden'),
							'taxonomy' => 'event_category'),
					array(	'name' => __('Releases Category','replay'),
							'id' => 'releases_category',
							'type' => 'select_category',
							'attributes' => array('class'=>'template-releases-child child-option hidden'),
							'taxonomy' => 'release_category'),
					array(	'name' => __('Galleries Category','replay'),
							'id' => 'galleries_category',
							'type' => 'select_category',
							'attributes' => array('class'=>'template-gallery-child child-option hidden'),
							'taxonomy' => 'gallery_category'),
					array(	'name' => __('Videos Category','replay'),
							'id' => 'videos_category',
							'type' => 'select_category',
							'attributes' => array('class'=>'template-video-child child-option hidden'),
							'taxonomy' => 'video_category'),
				),			
			),
		
			//Artists
			array(
				'id' => 'artist_metabox',
				'title' =>  __('Social Links', 'replay'),
				'page' => 'artist',
				'context' => 'normal',
				'priority' => 'high',
				'options' => array(
					array(	'name' => __('Profile Image','replay'),
							'desc' => '',
							'id' => 'profile_image',
							'type' => 'uploader'),
					array(	'name' => __('Facebook','replay'),
							'desc' => '',
							'id' => 'facebook',
							'type' => 'text'),
					array(	'name' => __('Twitter','replay'),
							'desc' => '',
							'id' => 'twitter',
							'type' => 'text'),
					array(	'name' => __('Google','replay'),
							'desc' => '',
							'id' => 'google',
							'type' => 'text'),
					array(	'name' => __('LastFM','replay'),
							'desc' => '',
							'id' => 'lastfm',
							'type' => 'text'),
					array(	'name' => __('Tumblr','replay'),
							'desc' => '',
							'id' => 'tumblr',
							'type' => 'text'),
					array(	'name' => __('Blogger','replay'),
							'desc' => '',
							'id' => 'blogger',
							'type' => 'text'),
					array(	'name' => __('MySpace','replay'),
							'desc' => '',
							'id' => 'myspace',
							'type' => 'text'),
					array(	'name' => __('ReverbNation','replay'),
							'desc' => '',
							'id' => 'reverbnation',
							'type' => 'text'),
				),			
			),
			
			//Events
			array(
				'id' => 'event_metabox',
				'title' =>  __('Event Options', 'replay'),
				'page' => 'event',
				'context' => 'normal',
				'priority' => 'high',
				'options' => array(	
					array(							
							'name' => __('Status', 'replay'),
							'type' => 'select',
							'id' => 'status',
							'options' => array(
								'active' => __('Active', 'replay'),								
								'sold' => __('Sold Out', 'replay'),
								'free' => __('Free Entry', 'replay'),
								'cancelled' => __('Cancelled', 'replay'),
							)
					),
					array(	'name' => __('Artists','replay'),
							'desc' => __('Use the CTRL or COMMAND key to select multiple items.','replay'),
							'id' => 'artists',
							'type' => 'select_post',
							'attributes' => array('multiple' => 'multiple'),
							'post_type' => 'artist'),					
					array(	'name' => __('Place','replay'),
							'desc' => __('Place where event is held.','replay'),
							'id' => 'place',
							'type' => 'text'),						
					array(	'name' => __('Date','replay'),
							'desc' => __('Date that the event will start.','replay'),
							'id' => 'date',
							'type' => 'date'),
					array(	'name' => __('Details','replay'),
							'desc' => __('Link to the page with details.','replay'),
							'id' => 'details',
							'type' => 'text'),
					array(	'name' => __('Gallery','replay'),
							'desc' => __('Photos of the past event.','replay'),
							'id' => 'gallery',
							'default_option' => '-',
							'type' => 'select_post',
							'post_type' => 'gallery'),
					array(	'name' => __('Video','replay'),
							'desc' => __('Video of the past event.','replay'),
							'id' => 'video',
							'default_option' => '-',
							'type' => 'select_post',
							'post_type' => 'video'),					
					array(	'name' => __('Buy Link','replay'),
							'desc' => __('Link to buy the tickets.','replay'),
							'id' => 'link',
							'type' => 'text'),				
				),			
			),
						
			//Slides
			array(
				'id' => 'slide_metabox',
				'title' =>  __('Slide Options', 'replay'),
				'page' => 'slide',
				'context' => 'normal',
				'priority' => 'high',
				'options' => array(	
					array(	'name' => __('Image Width','replay'),
							'desc' => __('Width of the slide image.','replay'),
							'id' => 'width',
							'type' => 'select',
							'options' => array(
								'300' => '300',
								'400' => '400',
								'500' => '500',
								'600' => '600'
							)),
				
					array(	'name' => __('Image Link','replay'),
							'desc' => __('Link for the slide image.','replay'),
							'id' => 'link',
							'type' => 'text'),
							
					array(	'name' => __('Video Code','replay'),
							'desc' => __('Add embedded video code here.','replay'),
							'id' => 'video_code',
							'type' => 'textarea'),
					
					array(	'name' => __('Audio URL','replay'),
							'desc' => 'Audio URL for the featured track.',
							'id' => 'track_url',
							'type' => 'uploader'),
							
					array(	'name' => __('Download Link','replay'),
							'desc' => 'Link to download the featured track.',
							'id' => 'track_link',
							'type' => 'text'),

				),			
			),
			
			
			//Releases
			array(
				'id' => 'release_metabox',
				'title' =>  __('Release Options', 'replay'),
				'page' => 'release',
				'context' => 'normal',
				'priority' => 'high',				
				'options' => array(
					array(	'name' => __('Artists','replay'),
							'desc' => __('Use the CTRL or COMMAND key to select multiple items.','replay'),
							'id' => 'artists',
							'type' => 'select_post',
							'attributes' => array('multiple' => 'multiple'),
							'post_type' => 'artist'),
					array(	'name' => __('Date','replay'),
							'desc' => __('Date of the release.','replay'),
							'id' => 'date',
							'type' => 'date'),
					array(	'name' => __('Tracks','replay'),
							'desc' => __('Add tracks of this release.','replay'),
							'id' => 'tracks',
							'type' => 'tracks'),
					array(	'name' => __('Links to Buy','replay'),
							'desc' => __('Add links to buy this release.','replay'),
							'id' => 'links',
							'type' => 'links'),
				),
			),
			
			//Videos
			array(
				'id' => 'video_metabox',
				'title' =>  __('Video Options', 'replay'),
				'page' => 'video',
				'context' => 'normal',
				'priority' => 'high',				
				'options' => array(
					array(	'name' => __('Artists','replay'),
							'desc' => __('Use the CTRL or COMMAND key to select multiple items.','replay'),
							'id' => 'artists',
							'type' => 'select_post',
							'attributes' => array('multiple' => 'multiple'),
							'post_type' => 'artist'),
					array(	'name' => __('Video Code','replay'),
							'desc' => __('Add embedded video code here.','replay'),
							'id' => 'code',
							'type' => 'textarea'),
				),
			),
			
			//Galleries
			array(
				'id' => 'gallery_metabox',
				'title' =>  __('Gallery Options', 'replay'),
				'page' => 'gallery',
				'context' => 'normal',
				'priority' => 'high',				
				'options' => array(
					array(	'name' => __('Artists','replay'),
							'desc' => __('Use the CTRL or COMMAND key to select multiple items.','replay'),
							'id' => 'artists',
							'type' => 'select_post',
							'attributes' => array('multiple' => 'multiple'),
							'post_type' => 'artist'),
					array(	'name' => __('Images','replay'),
							'desc' => __('Add images for this gallery.','replay'),
							'id' => 'images',
							'type' => 'gallery'),
				),
			),
		),
		
		'shortcodes' => array(
		
			//Block
			'block' => array(
				'options' => array(
					'title' => array(
						'std' => '',
						'type' => 'text',
						'label' => __('Block Title', 'replay'),
					),
					'content' => array(
						'std' => '',
						'type' => 'textarea',
						'label' => __('Block Content', 'replay'),
					),
				),
				'shortcode' => '[block title="{{title}}"]{{content}}[/block]',			
				'popup_title' => __('Insert Block Shortcode', 'replay')
			),
			
			//Buttons
			'button' => array(
				'options' => array(
					'color' => array(
						'type' => 'select',
						'label' => __('Button Color', 'replay'),
						'options' => array(
							'default' => __('Default', 'replay'),
							'grey' => __('Grey', 'replay'),						
						)
					),
					'size' => array(
						'type' => 'select',
						'label' => __('Button Size', 'replay'),
						'options' => array(
							'small' => __('Small', 'replay'),
							'medium' => __('Medium', 'replay'),
							'large' => __('Large', 'replay')
						)
					),
					'url' => array(
						'std' => '',
						'type' => 'text',
						'label' => __('Button URL', 'replay'),
					),
					'content' => array(
						'std' => '',
						'type' => 'text',
						'label' => __('Button Text', 'replay'),
					)
				),
				'shortcode' => '[button url="{{url}}" color="{{color}}" size="{{size}}"]{{content}}[/button]',
				'popup_title' => __('Insert Button Shortcode', 'replay')
			),
			
			//Columns
			'column' => array(
				'options' => array(),
				'shortcode' => '{{child_shortcode}}',
				'popup_title' => __('Insert Columns Shortcode', 'replay'),
				'child_shortcode' => array(
					'options' => array(
						'column' => array(
							'type' => 'select',
							'label' => __('Column Width', 'replay'),
							'options' => array(
								'one_third' => __('One Third', 'replay'),
								'one_third_last' => __('One Third Last', 'replay'),
								'two_third' => __('Two Thirds', 'replay'),
								'two_third_last' => __('Two Thirds Last', 'replay'),
								'one_half' => __('One Half', 'replay'),
								'one_half_last' => __('One Half Last', 'replay'),
								'one_fourth' => __('One Fourth', 'replay'),
								'one_fourth_last' => __('One Fourth Last', 'replay'),
								'three_fourth' => __('Three Fourth', 'replay'),
								'three_fourth_last' => __('Three Fourth Last', 'replay'),
							)
						),
						'content' => array(
							'std' => '',
							'type' => 'textarea',
							'label' => __('Column Content', 'replay'),
						)
					),
					'shortcode' => '[{{column}}]{{content}}[/{{column}}] ',
					'clone_button' => __('Add Columns Shortcode', 'replay')
				)
			),
			
			//Contact Form
			'contact_form' => array(
				'shortcode' => '[contact_form]',
				'popup_title' => __('Insert Contact Form Shortcode', 'replay')
			),
			
			//Divider
			'divider' => array(
				'options' => array(
					'top' => array(
						'std' => '',
						'type' => 'text',
						'label' => __('Top Space', 'replay'),
					),
					'bottom' => array(
						'std' => '',
						'type' => 'text',
						'label' => __('Bottom Space', 'replay'),
					),
				),
				'shortcode' => '[divider top="{{top}}" bottom="{{bottom}}"][/divider]',			
				'popup_title' => __('Insert Divider Shortcode', 'replay')
			),
			
			//Video
			'video' => array(
				'options' => array(
					'content' => array(
						'type' => 'textarea',
						'label' => __('Video Code', 'replay'),
						'std' => ''
					),
				),
				'shortcode' => '[video]{{content}}[/video]',
				'popup_title' => __('Insert Video Shortcode', 'replay')
			),
			
			//Audio
			'audio' => array(
				'options' => array(
					'url' => array(
						'type' => 'text',
						'label' => __('Track URL', 'replay'),
						'std' => ''
					),
				),
				'shortcode' => '[audio url="{{url}}"]',
				'popup_title' => __('Insert Audio Shortcode', 'replay')
			),
		
		
		),		
		
		//Theme custom styles
		'custom_styles' => array (
			array(
				'elements' => 'body',
				'attributes' => array('background-image'=>'background_pattern','font-family'=>'content_font')
			),
			array(
				'elements' => 'body',
				'attributes' => array('background-image'=>'background_image')
			),
			array(
				'elements' => '.ribbon-slider-container,.main-fade-slider',
				'attributes' => array('background-image'=>'slider_background_pattern')
			),
			array(
				'elements' => '.ribbon-slider-container,.main-fade-slider',
				'attributes' => array('background-image'=>'slider_background_image')
			),
			array(
				'elements' => 'h1, h2, h3, h4, h5, h6, th, .supheader .logo, .subheader .menu a, .page-title .container > span, .content-block .block-title, .ribbon-caption-title, .featured-event .event-date, .events-list .event-date, .events-list .event-option > span, .gallery-thumbnail .caption, .video-thumbnail .caption, input[type="submit"], input[type="button"], .button',
				'attributes' => array('font-family'=>'heading_font')
			),
			array(
				'elements' => 'a, h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover, .release-thumbnail  .tip-content a:hover, .featured-event .event-date-number, .releases-filter li.current a',
				'attributes' => array('color'=>'primary_color')
			),
			array(
				'elements' => '.ribbon-caption-title .ribbon-caption-background, .jp-progress .jp-play-bar, .button, input[type="submit"], input[type="button"]',
				'attributes' => array('background-color'=>'primary_color')
			),
			array(
				'elements' => '::-moz-selection',
				'attributes' => array('background-color'=>'primary_color')
			),
			array(
				'elements' => '::selection',
				'attributes' => array('background-color'=>'primary_color')
			),
		),
	),

	
	//Options
	'options' => array (
			
		//General Settings
		array(	'name' => __('General','replay'),
				'type' => 'page'),
					
			array(	'name' => __('Site Favicon','replay'),
					'description' => __('Upload an image for your site favicon.','replay'),
					'id' => 'favicon',
					'type' => 'uploader'),
					
			array(	'name' => __('Site Logo Type','replay'),
					'id' => 'logo_type',
					'options' => array('image' => __('Image','replay'), 'text' => __('Text','replay')),
					'type' => 'select'),
					
			array(	'name' => __('Site Logo Image','replay'),
					'description' => __('Upload an image for your site logo.','replay'),
					'id' => 'logo_image',
					'type' => 'uploader',
					'parent' => array('logo_type','0')),
					
			array(	'name' => __('Site Logo Text','replay'),
					'description' => __('Enter the text for your site logo.','replay'),
					'id' => 'logo_text',
					'type' => 'text',
					'parent' => array('logo_type','1')),
					
			array(	'name' => __('Login Logo Image','replay'),
					'description' => __('Upload an image to show on the login page.','replay'),
					'id' => 'login_logo',
					'type' => 'uploader'),
					
			array(	'name' => __('Copyright Text','replay'),
					'description' => __('Enter the copyright text to be displayed in the footer.','replay'),
					'id' => 'copyright_text',
					'default' => '',
					'type' => 'textarea'),
					
			array(	'name' => __('Tracking Code','replay'),
					'description' => __('Add analytics tracking code here.','replay'),
					'id' => 'tracking_code',
					'default' => '',
					'type' => 'textarea'),				
				
		//Styling
		array(	'name' => __('Styling','replay'),
				'type' => 'page'),
				
			array(	'name' => __('Custom CSS','replay'),
					'description' => __('Write CSS rules here to overwrite the default styles.','replay'),
					'default' => '',
					'id' => 'css',
					'type' => 'textarea'),
					
			array(	'name' => __('Primary Theme Color','replay'),
					'default' => '#EE3450',
					'id' => 'primary_color',
					'type' => 'color'),
					
			array(	'name' => __('Theme Background Type','replay'),
					'id' => 'background_type',
					'options' => array('default' => __('Default','replay'), 'custom' => __('Custom','replay')),
					'description' => __('Choose from the default patterns or upload your own image.','replay'),
					'type' => 'select'),
					
			array(	'name' => __('Theme Background Pattern','replay'),
					'id' => 'background_pattern',
					'options' => array(
										THEME_URI.'images/patterns/pattern_17.png'=>THEME_URI.'images/patterns/pattern_17_thumb.png',
										THEME_URI.'images/patterns/pattern_1.png'=>THEME_URI.'images/patterns/pattern_1_thumb.png', 
										THEME_URI.'images/patterns/pattern_2.png'=>THEME_URI.'images/patterns/pattern_2_thumb.png', 
										THEME_URI.'images/patterns/pattern_3.png'=>THEME_URI.'images/patterns/pattern_3_thumb.png', 
										THEME_URI.'images/patterns/pattern_4.png'=>THEME_URI.'images/patterns/pattern_4_thumb.png', 
										THEME_URI.'images/patterns/pattern_5.png'=>THEME_URI.'images/patterns/pattern_5_thumb.png', 
										THEME_URI.'images/patterns/pattern_6.png'=>THEME_URI.'images/patterns/pattern_6_thumb.png', 
										THEME_URI.'images/patterns/pattern_7.png'=>THEME_URI.'images/patterns/pattern_7_thumb.png', 
										THEME_URI.'images/patterns/pattern_8.png'=>THEME_URI.'images/patterns/pattern_8_thumb.png', 
										THEME_URI.'images/patterns/pattern_9.png'=>THEME_URI.'images/patterns/pattern_9_thumb.png', 
										THEME_URI.'images/patterns/pattern_10.png'=>THEME_URI.'images/patterns/pattern_10_thumb.png', 
										THEME_URI.'images/patterns/pattern_11.png'=>THEME_URI.'images/patterns/pattern_11_thumb.png', 
										THEME_URI.'images/patterns/pattern_12.png'=>THEME_URI.'images/patterns/pattern_12_thumb.png', 
										THEME_URI.'images/patterns/pattern_13.png'=>THEME_URI.'images/patterns/pattern_13_thumb.png', 
										THEME_URI.'images/patterns/pattern_14.png'=>THEME_URI.'images/patterns/pattern_14_thumb.png', 
										THEME_URI.'images/patterns/pattern_15.png'=>THEME_URI.'images/patterns/pattern_15_thumb.png', 
										THEME_URI.'images/patterns/pattern_16.png'=>THEME_URI.'images/patterns/pattern_16_thumb.png', 
										),
					'type' => 'select_image',				
					'parent' => array('background_type','0')),
					
			array(	'name' => __('Theme Background Image','replay'),
					'id' => 'background_image',
					'type' => 'uploader',
					'parent' => array('background_type','1')),
					
			array(	'name' => __('Slider Background Type','replay'),
					'id' => 'slider_background_type',
					'options' => array('default' => __('Default','replay'), 'custom' => __('Custom','replay')),
					'description' => __('Choose from the default patterns or upload your own image.','replay'),
					'type' => 'select'),
					
			array(	'name' => __('Slider Background Pattern','replay'),
					'id' => 'slider_background_pattern',
					'options' => array(
										THEME_URI.'images/patterns/pattern_17.png'=>THEME_URI.'images/patterns/pattern_17_thumb.png',
										THEME_URI.'images/patterns/pattern_1.png'=>THEME_URI.'images/patterns/pattern_1_thumb.png', 
										THEME_URI.'images/patterns/pattern_2.png'=>THEME_URI.'images/patterns/pattern_2_thumb.png', 
										THEME_URI.'images/patterns/pattern_3.png'=>THEME_URI.'images/patterns/pattern_3_thumb.png', 
										THEME_URI.'images/patterns/pattern_4.png'=>THEME_URI.'images/patterns/pattern_4_thumb.png', 
										THEME_URI.'images/patterns/pattern_5.png'=>THEME_URI.'images/patterns/pattern_5_thumb.png', 
										THEME_URI.'images/patterns/pattern_6.png'=>THEME_URI.'images/patterns/pattern_6_thumb.png', 
										THEME_URI.'images/patterns/pattern_7.png'=>THEME_URI.'images/patterns/pattern_7_thumb.png', 
										THEME_URI.'images/patterns/pattern_8.png'=>THEME_URI.'images/patterns/pattern_8_thumb.png', 
										THEME_URI.'images/patterns/pattern_9.png'=>THEME_URI.'images/patterns/pattern_9_thumb.png', 
										THEME_URI.'images/patterns/pattern_10.png'=>THEME_URI.'images/patterns/pattern_10_thumb.png', 
										THEME_URI.'images/patterns/pattern_11.png'=>THEME_URI.'images/patterns/pattern_11_thumb.png', 
										THEME_URI.'images/patterns/pattern_12.png'=>THEME_URI.'images/patterns/pattern_12_thumb.png', 
										THEME_URI.'images/patterns/pattern_13.png'=>THEME_URI.'images/patterns/pattern_13_thumb.png', 
										THEME_URI.'images/patterns/pattern_14.png'=>THEME_URI.'images/patterns/pattern_14_thumb.png', 
										THEME_URI.'images/patterns/pattern_15.png'=>THEME_URI.'images/patterns/pattern_15_thumb.png', 
										THEME_URI.'images/patterns/pattern_16.png'=>THEME_URI.'images/patterns/pattern_16_thumb.png', 
										),
					'type' => 'select_image',				
					'parent' => array('slider_background_type','0')),
					
			array(	'name' => __('Slider Background Image','replay'),
					'id' => 'slider_background_image',
					'type' => 'uploader',
					'parent' => array('slider_background_type','1')),
					
			array(	'name' => __('Headings Font','replay'),
					'id' => 'heading_font',
					'options' => array('Oswald' => 'Oswald', 'Anton' => 'Anton', 'Francois One' => 'Francois One',  'Lato' => 'Lato', 'Lobster' => 'Lobster', 'Mako' => 'Mako', 'Oxygen' => 'Oxygen', 'Pacifico' => 'Pacifico', 'Vollkorn' => 'Vollkorn'),
					'type' => 'select'),
					
			array(	'name' => __('Content Font','replay'),
					'id' => 'content_font',
					'options' => array('Open Sans, sans-serif' => 'Open Sans', 'Arial, sans-serif' => 'Arial', 'Georgia, sans-serif' => 'Georgia', 'Lucida Sans, sans-serif' => 'Lucida Sans', 'Tahoma, sans-serif' => 'Tahoma', 'Times New Roman, sans-serif' => 'Times New Roman', 'Trebuchet MS, sans-serif' => 'Trebuchet MS', 'Verdana, sans-serif' => 'Verdana'),
					'type' => 'select'),
					
		//Header
		array(	'name' => __('Header','replay'),
				'type' => 'page'),
				
		array(	'name' => __('Audio Player Code','replay'),
				'description' => __('Add any audio player code here.','replay'),
				'id' => 'player_code',
				'default' => '',
				'type' => 'textarea'),
				
		array(	'name' => __('Enable Autoplay','replay'),
				'id' => 'player_autoplay',
				'type' => 'checkbox'),	
				
		array(	'name' => __('Slider Type','replay'),
				'id' => 'slider_type',
				'options' => array('ribbon' => __('Ribbon Slider','replay'), 'fade' => __('Fade Slider','replay')),
				'type' => 'select'),
				
		array(	'name' => __('Slider Pause','replay'),
				'default' => '0',
				'id' => 'slider_pause',
				'attributes' => array('min_value' => '0', 'max_value' => '20000', 'unit' => 'ms'),
				'type' => 'slider'),
				
		array(	'name' => __('Transition Speed','replay'),
				'default' => '300',
				'id' => 'slider_speed',
				'attributes' => array('min_value' => '100', 'max_value' => '1000', 'unit' => 'ms'),
				'type' => 'slider'),
				
		array(	'name' => __('Disable Mousewheel Scrolling','replay'),
				'id' => 'slider_mousewheel',
				'type' => 'checkbox',
				'parent' => array('slider_type','0')),
				
		//Social
		array(	'name' => __('Social','replay'),
				'type' => 'page'),
				
			array(	'name' => __('Share Button Code','replay'),
					'description' => __('Add any share buttons code here.','replay'),
					'id' => 'share_button',
					'default' => '',
					'type' => 'textarea'),		
					
			array(	'name' => __('RSS Link','replay'),
					'id' => 'rss_link',
					'type' => 'text'),
					
			array(	'name' => __('Facebook Link','replay'),
					'id' => 'facebook_link',
					'type' => 'text'),
					
			array(	'name' => __('Twitter Link','replay'),
					'id' => 'twitter_link',
					'type' => 'text'),
					
			array(	'name' => __('Google Link','replay'),
					'id' => 'google_link',
					'type' => 'text'),

			array(	'name' => __('Flickr Link','replay'),
					'id' => 'flickr_link',
					'type' => 'text'),
					
			array(	'name' => __('Tumblr Link','replay'),
					'id' => 'tumblr_link',
					'type' => 'text'),

			array(	'name' => __('LinkedIn Link','replay'),
					'id' => 'linkedin_link',
					'type' => 'text'),		
					
			array(	'name' => __('YouTube Link','replay'),
					'id' => 'youtube_link',
					'type' => 'text'),
					
			array(	'name' => __('Vimeo Link','replay'),
					'id' => 'vimeo_link',
					'type' => 'text'),
					
			array(	'name' => __('LastFM Link','replay'),
					'id' => 'lastfm_link',
					'type' => 'text'),
					
			array(	'name' => __('ReverbNation Link','replay'),
					'id' => 'reverbnation_link',
					'type' => 'text'),		
				
		//Blog
		array(	'name' => __('Blog','replay'),
				'type' => 'page'),
				
			array(	'name' => __('Blog Layout','replay'),
				'id' => 'blog_layout',
				'options' => array(									
							'right'=>THEMEX_URI.'admin/images/layouts/3.png',
							'left'=>THEMEX_URI.'admin/images/layouts/2.png',
							),
				'type' => 'select_image'),
				
			array(	'name' => __('Blog Title','replay'),
				'id' => 'blog_title',
				'type' => 'text'),
				
		//Artists
		array(	'name' => __('Artists','replay'),
				'type' => 'page'),
				
			array(	'name' => __('Artists Layout','replay'),
				'id' => 'artists_layout',
				'options' => array(
									'one-third'=>THEMEX_URI.'admin/images/layouts/5.png',
									'one-fourth'=>THEMEX_URI.'admin/images/layouts/6.png',
									),
				'type' => 'select_image'),
				
			array(	'name' => __('Artists Per Page','replay'),
				'id' => 'artists_limit',
				'default' => '9',
				'type' => 'number'),
				
			array(	'name' => __('Artists Order','replay'),
				'id' => 'artists_order',
				'options' => array('date' => __('Latest','replay'), 'title' => __('Alphabetically','replay')),
				'type' => 'select'),
				
			array(	'name' => __('Thumbnails Height','replay'),
				'default' => '470',
				'id' => 'artists_height',
				'attributes' => array('min_value' => '100', 'max_value' => '700', 'unit' => 'px'),
				'type' => 'slider'),			
				
			array(	'name' => __('Artist Releases Order','replay'),
				'id' => 'artist_releases_order',
				'options' => array('date' => __('Latest','replay'), 'rand' => __('Random','replay'), 'related' => __('Related','replay'),),
				'type' => 'select'),
				
			array(	'name' => __('Artist Releases Number','replay'),
				'id' => 'artist_releases_count',
				'default' => '8',
				'type' => 'number'),
				
			array(	'name' => __('Artist Events Number','replay'),
				'id' => 'artist_events_count',
				'default' => '1',
				'type' => 'number'),
				
			array(	'name' => __('Hide Artist Releases','replay'),
				'id' => 'artist_releases',
				'type' => 'checkbox'),
							
			array(	'name' => __('Hide Artist Events','replay'),
				'id' => 'artist_events',
				'type' => 'checkbox'),	
				
			array(	'name' => __('Hide Artist Videos','replay'),
				'id' => 'artist_videos',
				'type' => 'checkbox'),
				
			array(	'name' => __('Hide Artist Gallery','replay'),
				'id' => 'artist_galleries',
				'type' => 'checkbox'),	

		//Releases
		array(	'name' => __('Releases','replay'),
				'type' => 'page'),
				
			array(	'name' => __('Releases Layout','replay'),
				'id' => 'releases_layout',
				'options' => array(
									'right'=>THEMEX_URI.'admin/images/layouts/3.png',
									'left'=>THEMEX_URI.'admin/images/layouts/2.png',									
									'fullwidth'=>THEMEX_URI.'admin/images/layouts/1.png',
									),
				'type' => 'select_image'),
				
			array(	'name' => __('Releases Per Page','replay'),
				'id' => 'releases_limit',
				'default' => '9',
				'type' => 'number'),			
				
			array(	'name' => __('Related Releases Order','replay'),
				'id' => 'release_releases_order',
				'options' => array('date' => __('Latest','replay'), 'rand' => __('Random','replay'), 'related' => __('Related','replay'),),
				'type' => 'select'),
				
			array(	'name' => __('Related Releases Number','replay'),
				'id' => 'release_releases_count',
				'default' => '8',
				'type' => 'number'),
				
			array(	'name' => __('Hide Related Releases','replay'),
				'id' => 'release_releases',
				'type' => 'checkbox'),
				
			array(	'name' => __('Hide Artists Filter','replay'),
				'id' => 'releases_filter',
				'type' => 'checkbox'),
				
		//Events
		array(	'name' => __('Events','replay'),
				'type' => 'page'),
				
			array(	'name' => __('Events Layout','replay'),
				'id' => 'events_layout',
				'options' => array (								
					'right'=>THEMEX_URI.'admin/images/layouts/3.png',
					'left'=>THEMEX_URI.'admin/images/layouts/2.png',
				),
				'type' => 'select_image'),
				
			array(	'name' => __('Date Format','replay'),
				'id' => 'events_date_format',
				'options' => array (						
					'd/m/Y'=>'DD/MM/YY',
					'm/d/Y'=>'MM/DD/YY',
				),
				'type' => 'select'),
				
			array(	'name' => __('Hide Past Events','replay'),
				'id' => 'events_past',
				'type' => 'checkbox'),	
				
		//Gallery
		array(	'name' => __('Gallery','replay'),
				'type' => 'page'),
				
				array(	'name' => __('Galleries Layout','replay'),
				'id' => 'gallery_layout',
				'options' => array(
									'one-third'=>THEMEX_URI.'admin/images/layouts/5.png',
									'one-fourth'=>THEMEX_URI.'admin/images/layouts/6.png',
									),
				'type' => 'select_image'),
				
				array(	'name' => __('Galleries Per Page','replay'),
				'id' => 'gallery_limit',
				'default' => '9',
				'type' => 'number'),
				
				array(	'name' => __('Thumbnails Height','replay'),
				'default' => '308',
				'id' => 'gallery_height',
				'attributes' => array('min_value' => '100', 'max_value' => '700', 'unit' => 'px'),
				'type' => 'slider'),
				
				array(	'name' => __('Related Galleries Order','replay'),
				'id' => 'gallery_order',
				'options' => array('date' => __('Latest','replay'), 'rand' => __('Random','replay'), 'related' => __('Related','replay'),),
				'type' => 'select'),
				
				array(	'name' => __('Related Galleries Number','replay'),
					'id' => 'gallery_count',
					'default' => '6',
					'type' => 'number'),
					
				array(	'name' => __('Hide Related Galleries','replay'),
					'id' => 'gallery_related',
					'type' => 'checkbox'),
				
				
		//Video
		array(	'name' => __('Video','replay'),
				'type' => 'page'),
				
				array(	'name' => __('Videos Layout','replay'),
				'id' => 'video_layout',
				'options' => array(
									'one-third'=>THEMEX_URI.'admin/images/layouts/5.png',
									'one-fourth'=>THEMEX_URI.'admin/images/layouts/6.png',
									),
				'type' => 'select_image'),
				
				array(	'name' => __('Videos Per Page','replay'),
				'id' => 'video_limit',
				'default' => '9',
				'type' => 'number'),
				
				array(	'name' => __('Thumbnails Height','replay'),
				'default' => '308',
				'id' => 'video_height',
				'attributes' => array('min_value' => '100', 'max_value' => '700', 'unit' => 'px'),
				'type' => 'slider'),
				
				array(	'name' => __('Related Videos Order','replay'),
				'id' => 'video_order',
				'options' => array('date' => __('Latest','replay'), 'rand' => __('Random','replay'), 'related' => __('Related','replay'),),
				'type' => 'select'),
				
				array(	'name' => __('Related Videos Number','replay'),
					'id' => 'video_count',
					'default' => '6',
					'type' => 'number'),
					
				array(	'name' => __('Hide Related Videos','replay'),
					'id' => 'video_related',
					'type' => 'checkbox'),		

		//Custom Sidebars
		array(	'name' => __('Sidebars','replay'),
				'type' => 'page'),
				
		array(	'type' => 'themex_widgetiser' ),
		
		//Contact Form
		array(	'name' => __('Contact Form','replay'),
				'type' => 'page'),
				
		array(	'type' => 'themex_form' ),	
				
		//Mailing List
		array(	'name' => __('Mailing List','replay'),
				'type' => 'page'),
				
		array(	'name' => '',
				'id' => 'mailing_list',
				'default' => '',
				'description' => __('This is the list of subcribers from Newsletter Widget.','replay'),
				'type' => 'textarea'),

	),

);
?>