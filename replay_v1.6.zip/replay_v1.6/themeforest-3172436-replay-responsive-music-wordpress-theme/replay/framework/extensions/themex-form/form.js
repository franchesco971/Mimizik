jQuery(document).ready(function($){

	$('#themex_form').submit(function(){

		var message=$('#themex_form_message');
		var submitButton=$('#themex_form_submit');
		
		$('#themex_form .formatted-form-loader').show();
		
		message.slideUp(750,function() {
		message.hide();
		
		var data = {
			action: 'themex_form',
			data: $('form#themex_form').serialize()
		};		
		
		$.post(ajaxurl, data, function(response) {
			message.html(response);
			message.slideDown('slow');
			submitButton.removeAttr('disabled');
			$('#themex_form .formatted-form-loader').hide();
			if(response.match('success') != null) {
				$('#themex_form').slideUp('slow');
			}
		});
		
		});
		
		return false; 
	
	});
});