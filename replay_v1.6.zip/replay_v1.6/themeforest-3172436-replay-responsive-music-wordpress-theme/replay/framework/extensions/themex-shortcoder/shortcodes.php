<?php
//Divider

function themex_divider( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'bottom' => '3',
		'top' => '0'
    ), $atts));
   $out='<div class="clear"></div><div class="divider" style="margin-bottom:'.$bottom.'em; margin-top:'.$top.'em;"></div>';
   return $out;
}

add_shortcode('divider', 'themex_divider');

//Buttons

function themex_button( $atts, $content = null ) {
	
	extract(shortcode_atts(array(
		'url'     	 => '#',
		'color'   => 'default',
		'size'	=> 'small'
    ), $atts));
	
   return '<a href="'.$url.'" class="button '.$size.' '.$color.'"><span>'.do_shortcode($content).'</span></a>';
}

add_shortcode('button', 'themex_button');

//Contact Form

function themex_contact_form( $atts, $content = null ) {
	ob_start();
	ThemexForm::renderData();
    $out=ob_get_contents();
	ob_end_clean();
    return $out;
}

add_shortcode('contact_form', 'themex_contact_form');

//Content Block
function themex_block( $atts, $content = null ) {
	$out='<div class="content-block">';
	if(isset($atts['title'])) {
		$out.='<div class="block-title"><span>'.$atts['title'].'</span></div>';
	}
	$out.='<div class="block-content">'.do_shortcode($content).'</div></div>';
	return $out;
}

add_shortcode('block', 'themex_block');

//Audio
function themex_audio( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'url'     	 => '#',
    ), $atts));
	
	wp_enqueue_script('audioJS',THEME_URI.'js/audiojs/audio.min.js');
	$out='<div class="track-player"><audio src="'.$url.'" preload="none"></audio></div>';
	
	return $out;
}
add_shortcode('audio', 'themex_audio');

//Video
function themex_video( $atts, $content = null ) {
   return '<div class="embedded-video">'.do_shortcode(html_entity_decode($content)).'</div>';
}
add_shortcode('video', 'themex_video');

//Columns

function themex_one_third( $atts, $content = null ) {
   return '<div class="one-third column">'.do_shortcode($content).'</div>';
}

add_shortcode('one_third', 'themex_one_third');

function themex_one_third_last( $atts, $content = null ) {
   return '<div class="one-third column last">'.do_shortcode($content).'</div><div class="clear"></div>';
}

add_shortcode('one_third_last', 'themex_one_third_last');

function themex_two_third( $atts, $content = null ) {
   return '<div class="two-third column">'.do_shortcode($content).'</div>';
}

add_shortcode('two_third', 'themex_two_third');

function themex_two_third_last( $atts, $content = null ) {
   return '<div class="two-third column last">'.do_shortcode($content).'</div><div class="clear"></div>';
}

add_shortcode('two_third_last', 'themex_two_third_last');

function themex_one_half( $atts, $content = null ) {
   return '<div class="one-half column">'.do_shortcode($content).'</div>';
}

add_shortcode('one_half', 'themex_one_half');

function themex_one_half_last( $atts, $content = null ) {
   return '<div class="one-half column last">'.do_shortcode($content).'</div><div class="clear"></div>';
}

add_shortcode('one_half_last', 'themex_one_half_last');

function themex_one_fourth( $atts, $content = null ) {
   return '<div class="one-fourth column">'.do_shortcode($content).'</div>';
}

add_shortcode('one_fourth', 'themex_one_fourth');

function themex_one_fourth_last( $atts, $content = null ) {
   return '<div class="one-fourth column last">'.do_shortcode($content).'</div><div class="clear"></div>';
}

add_shortcode('one_fourth_last', 'themex_one_fourth_last');

function themex_three_fourth( $atts, $content = null ) {
   return '<div class="three-fourth column">'.do_shortcode($content).'</div>';
}

add_shortcode('three_fourth', 'themex_three_fourth');

function themex_three_fourth_last( $atts, $content = null ) {
   return '<div class="three-fourth column last">'.do_shortcode($content).'</div><div class="clear"></div>';
}

add_shortcode('three_fourth_last', 'themex_three_fourth_last');
?>