<?php
//Site Logo
function themex_logo() {
	$logo_type=get_option('themex_logo_type');
	if($logo_type=='image' && get_option('themex_logo_image')) {
		$out='<img src="'.get_option('themex_logo_image').'" alt="">';
	} else if($logo_type=='text' && get_option('themex_logo_text')) {
		$out=get_option('themex_logo_text');
	} else {
		$out='<img src="'.THEME_URI.'images/logo.png" alt="" />';
	}
	echo $out;
}

//Login Logo
add_action('login_head', 'themex_login_logo');
function themex_login_logo() {
	$logo_url=get_option('themex_login_logo');
	if($logo_url) {
		echo '<style type="text/css">h1 a { background-image:url('.$logo_url.') !important; }</style>';
	}
}

//Tracking Code
function themex_footer() {
	if(get_option('themex_tracking_code')) {
		echo html_entity_decode(stripslashes_deep(get_option('themex_tracking_code')));
	}
}
add_action('wp_footer','themex_footer');

//Post Thumbnail
function themex_thumbnail($ID, $w = 0, $h = 0){
	global $blog_id;
	$src = wp_get_attachment_url( get_post_thumbnail_id($ID) );

	if (isset($blog_id) && $blog_id > 0) {
		$imageParts = explode('/files/', $src);
		if (isset($imageParts[1])) {
			$src = '/blogs.dir/' . $blog_id . '/files/' . $imageParts[1];
		}
	}

	$url = THEMEX_URI.'extensions/timthumb/timthumb.php?src='.urlencode($src);
	if($w = intval($w)){
		if($h!=0 && $h=intval($h)) {	
			$url.='&w='.$w.'&h='.$h.'&a=t';
		} else {
			$url.='&w='.$w;
		}
	}
	return $url;
}

//Page Title
function themex_page_title() {
	global $post;
	$out='';
	if(is_single()) {
		if($post->post_type=='gallery') {
			_e('Gallery','replay');
		} else if($post->post_type=='video') {
			_e('Videos','replay');
		} else if($post->post_type=='release') {
			_e('Releases','replay');
		} else {
			$categories=wp_get_post_terms($post->ID,'category');
			if(!empty($categories)) {
				$out=$categories[0]->name;
			} else {
				$out=$post->post_title;
			}
		}
	} else {
		$out=wp_title('', false);
	}
	
	echo $out;
}

//Custom Dropdown Menu
function themex_dropdown_menu($menu_slug) {
    if ( !( $locations = get_nav_menu_locations() ) || !isset( $locations[ $menu_slug ] ) ) {
		return;
	}
	
	$menu=wp_get_nav_menu_object( $locations[ $menu_slug ] );
	$menu_items=wp_get_nav_menu_items($menu->term_id);
	$out= '<select>';
	foreach ( (array) $menu_items as $key => $menu_item ) {
		$out.='<option value="'.$menu_item->url.'">'.$menu_item->title.'</option>';
	}
	$out.='</select>';	
	echo $out;
}

//Custom Comments
function themex_comment($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment; ?>
	<li id="comment-<?php comment_ID(); ?>">	
		<div class="comment">
			<div class="avatar-container">
				<?php echo get_avatar( $comment, $size='87', $default=THEME_URI.'images/avatar.png' ); ?>
				<div class="ribbon-caption">
					<div class="ribbon-caption-title">						
						<span><?php echo get_comment_reply_link(array_merge( $args, array('depth' => $depth, 'reply_text'=>__('Reply','replay'), 'max_depth' => $args['max_depth']))) ?></span>
						<span class="ribbon-caption-background"></span>
					</div>
				</div>
			</div>
			<div class="comment-text">
				<div class="comment-meta">
					<h4 class="comment-author"><?php echo get_comment_author_link(); ?></h4>
					<div class="comment-date"><?php themex_time(get_comment_time('U')); ?></div>
					<div class="clear"></div>
				</div>
				<?php comment_text(); ?>
			</div>
			<div class="clear"></div>
		</div>
<?php
}

//Custom Comments Form
function themex_comment_form_fields($fields) {
	unset($fields['url']);
	$fields['author']='<div class="column one-half"><div class="field-wrapper"><input id="author" name="author" type="text" value="" placeholder="'.__('Name','replay').'" size="30" aria-required="true" /></div></div>';
	$fields['email']='<div class="column one-half last"><div class="field-wrapper"><input id="email" name="email" type="text" value="" placeholder="'.__('Email','replay').'" size="30" aria-required="true" /></div></div>';
	return $fields;
}
add_filter('comment_form_default_fields','themex_comment_form_fields');

//Custom Pagination
function themex_pagination() {
	global $wp_query, $wp_rewrite;
	$query=$wp_query;
	$max = $query->max_num_pages;
	if (!$current = get_query_var('paged')) $current = 1;
	$a['base'] = str_replace(999999999, '%#%', get_pagenum_link(999999999));
	$a['total'] = $max;
	$a['current'] = $current;

	$a['mid_size'] = 5;
	$a['end_size'] = 1;
	$a['prev_text'] = '';
	$a['next_text'] = '';
	echo '<div class="pagination">'.paginate_links($a).'</div>';
}

//Time Difference
function themex_time($time=null) {
	global $post;
	if(is_null($time)) {
		$time=get_the_time('U');
	}
	echo human_time_diff( $time, current_time('timestamp') ) . __(' ago','replay');
}

//Artists List
function themex_artists($artists) {
	$artists_arr=array();
	parse_str($artists,$artists_arr);
	if(!empty($artists_arr)) {
		foreach($artists_arr as $artist) {
			$artist_names[]=get_the_title($artist);
		}
		$artists=implode(', ',$artist_names);
	}						
	return $artists;
}

//Event Title
function themex_event_title($event, $sep='') {	
	$out='';
	if($event['artists']!='') {
		$out.=themex_artists($event['artists']).' '.$sep.' '; 
	}
	if($event['details']!='') {
		$out.='<a href="'.$event['details'].'">'.$event['title'].'</a>';
	} else {
		$out.=$event['title'];
	}
	echo $out;
}

//Detect Slider Page
function themex_is_slider_page() {
	if(is_front_page() && get_option('themex_slider_type')!='fade') {
		return true;
	}
	return false;
}

//Detect Post Type
function themex_is_post_type($types) {
	global $post;
	foreach($types as $type) {
		if($type==$post->post_type) {
			return true;
		}
	}
	return false;
}

//Get Custom Posts
function themex_get_posts($type, $params, $count=-1, $filters=null, $order='date', $exclude=array() ) {
	$atts=array(
		'post_type' =>$type,
		'orderby' => $order,
		'post__not_in' => $exclude,
		'numberposts' => -1
	);
	
	if($order=='date' && $type!='event') {
		$atts['numberposts']=$count;
		$atts['orderby']='post_date';
	}
	
	if(is_array($filters)) {
		foreach($filters as $filter_name=>$filter_value) {
			if(strpos($filter_name, 'category') && isset($filter_value) && $filter_value!='') {
				$category=get_term( $filter_value, $filter_name );
				if(isset($category->slug)) {
					$atts[$filter_name]=$category->slug;
				}
			}
		}
	}

	$posts=get_posts($atts);
	$items=array();
	
	foreach($posts as $post) {
		$item['type']=$type;
		
		foreach($params as $param) {
			if($param=='title') {
				$item[$param]=$post->post_title;
			} else if($param=='ID') {
				$item[$param]=$post->ID;
			} else if($param=='permalink') {
				$item[$param]=get_permalink($post->ID);
			} else {
				$item[$param]=get_post_meta($post->ID, $type.'_'.$param, true);
			}			
		}
		
		if($type=='event') {
			$item['timestamp']=strtotime(str_replace('/','.',get_post_meta($post->ID, 'event_date', true)));
		}
		
		if(!is_null($filters) ) {
			foreach($filters as $filter_name=>$filter_value) {
				$filter_values=array();
				parse_str(get_post_meta($post->ID, $type.'_'.$filter_name, true),$filter_values);
				
				if(is_array($filter_value)) {					
					$common=array_intersect($filter_value, $filter_values);
					if(!empty($common)) {
						$items[]=$item;
					}
				} else if(in_array($filter_value,$filter_values) || strpos($filter_name, 'category')) {				
					$items[]=$item;
				}				
			}
		} else {
			$items[]=$item;
		}		
	}
	
	if($type=='event') {
		usort($items ,'themex_sort_events');
	}
	
	if($count!=-1) {
		return array_slice($items,0,$count);
	}
	return $items;
}

//Get Query
function themex_get_query($posts, $page_limit=-1, $paged=1) {
	$atts=array();	
	
	if(is_array($posts) && !empty($posts)) {
		$atts['post_type']=$posts[0]['type'];
		$atts['posts_per_page']=$page_limit;
		$atts['paged']=$paged;
		$atts['post__in']=array();
		
		foreach($posts as $post) {
			if(isset($post['ID'])) {
				$atts['post__in'][]=$post['ID'];
			}			
		}
		
	}
	return $atts;
}

//Sort Events
function themex_sort_events($a, $b) {
	return $a['timestamp']>$b['timestamp'];
}

//Filter Events
function themex_filter_events($items, $past=false) {
	$filtered_items=array();
	$current_time=time()-86400;
	foreach($items as $item) {
		if((($item['timestamp']>=$current_time && !$past) || ($item['timestamp']<$current_time && $past)) && $item['status']!='cancelled' && $item['status']!='sold') {
			$filtered_items[]=$item;
		}
	}
	return $filtered_items;
}

//Release Links
function themex_links($id) {
	parse_str(get_post_meta($id,'release_links',true),$links);
	
	$out='';
	if(isset($links[0]['label']) && isset($links[0]['url']) && $links[0]['label']!='' && $links[0]['url']!='') {
		$out='<div class="button-container ';
		if(count($links)>1) {
			$out.='tip-container';
		}
		$out.='"><a href="';
		if(count($links)==1) { 
			$out.=$links[0]['url'];
		} else {
			$out.='#';
		}
		$out.='" class="button small" target="_blank"><span>'.__('Buy Now','replay').'</span></a>';
		$out.='<div class="tip-cloud"><div class="tip-corner"></div><div class="tip-content"><ul>';
		if(is_array($links)) {
			foreach($links as $link) {
				$out.='<li><a href="'.$link['url'].'" target="_blank">'.stripslashes_deep($link['label']).'</a></li>';		
			}
		}
		$out.='</ul></div></div></div>';
	}
	
	return $out;
}

//Login Form
add_action('wp_ajax_themex_login', 'themex_login');
add_action('wp_ajax_nopriv_themex_login', 'themex_login');
function themex_login() {
	check_ajax_referer( 'themex_nonce', 'nonce' );

	$creds = array();
    $creds['user_login'] = $_POST['username'];
    $creds['user_password'] = $_POST['password'];
    $creds['remember'] = true;

    $user = wp_signon( $creds, false );

    if ( is_wp_error( $user ) ) {
        echo '<ul class="error"><li>'.__('Invalid password or username','replay').'.</li></ul>';
    } else {
		echo '<div class="success"></div>';
    }

    die();
}

//Logout Redirect
add_filter('logout_url', 'themex_logout_url', 10, 2); 
function themex_logout_url($logout_url, $redir) {
	return $logout_url.'&amp;redirect_to='.urlencode(home_url());
}

//Default User Role
add_filter('pre_option_default_role', 'themex_default_role');
function themex_default_role($default_role) {
	return 'contributor';
	return $default_role;
}

//User Permissions
add_action('admin_init', 'themex_user_permissions');
function themex_user_permissions() {
    $contributor = get_role('contributor');
    $contributor->add_cap('upload_files');
	$contributor->add_cap('edit_published_posts');
}

//Add JS URI variable
add_action( 'admin_head', 'themex_js_admin_vars' );
function themex_js_admin_vars() {
	echo '<script type="text/javascript">var themexUri="'.THEMEX_URI.'";</script>';
}

//Wrap Widget titles
add_filter('widget_title', 'themex_widget_title');
function themex_widget_title($title) {
   if($title=='') {
	return '<div class="clear"></div>';
   }
   return '<div class="block-title"><span>'.$title.'</span></div>';
}

//Enable shortcodes in widgets
add_filter('widget_text', 'do_shortcode');
?>