<?php 
/*
Template Name: Right Sidebar
*/

//show header
get_header(); 

//page content
if (have_posts()) : while (have_posts()) : the_post();
?>
<div class="two-third column">
	<?php the_content(); ?>
</div>
<?php endwhile; endif; ?>
<div class="one-third last column">
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>