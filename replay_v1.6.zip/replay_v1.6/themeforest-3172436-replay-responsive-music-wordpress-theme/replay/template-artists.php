<?php 
/*
Template Name: Artists
*/

//show header
get_header();

//page content
if (have_posts()) : while (have_posts()) : the_post();
	the_content();
endwhile; endif;

//page layout
$layout='one-third';
$row_limit=3;
$count=0;
if(get_option('themex_artists_layout')) {
	$layout=get_option('themex_artists_layout');
}
if($layout=='one-fourth') {
	$row_limit=4;
}

//thumbs height
$height=null;
if(get_option('themex_artists_height')) {
	$height=intval(get_option('themex_artists_height'));
}

//artists per page
$limit=9;
if(get_option('themex_artists_limit')) {
	$limit=get_option('themex_artists_limit');
}

//artists category
$category=get_post_meta($post->ID,'page_artists_category', true);
if($category!='' && $category!='0') {
	$category=get_term( intval($category), 'artist_category' );
	if(isset($category->slug)) {
		$category=$category->slug;
	}
}

//artists order
$orderby='date';
$order='DESC';
if(get_option('themex_artists_order')) {
	$orderby=get_option('themex_artists_order');
}
if($orderby=='title') {
	$order='ASC';
}

//artists query
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
query_posts(array(
	'post_type' =>'artist',
	'posts_per_page' => $limit,
	'paged' => $paged,
	'orderby' => $orderby,
	'order' => $order,
	'artist_category' => $category,
	'meta_key' => '_thumbnail_id',
));
?>
<div class="listing-block">
	<?php
	if (have_posts()) : while (have_posts()) : the_post();
	$count++;
	if(has_post_thumbnail()) {
	?>	
		<div class="<?php echo $layout; ?> column <?php if ($count==$row_limit) echo 'last'; ?>">
			<div class="artist-thumbnail">
				<a href="<?php the_permalink(); ?>"><img src="<?php echo themex_thumbnail($post->ID, 470, $height); ?>" class="fullwidth" alt="" /></a>
				<div class="ribbon-caption">
					<a href="<?php the_permalink(); ?>" class="ribbon-caption-title">
						<span><?php the_title(); ?></span>
						<span class="ribbon-caption-background"></span>
					</a>
				</div>
			</div>
		</div>
		<?php
		if($count==$row_limit) {
			$count=0;
		?>
		<div class="clear"></div>
		<?php } ?>
	<?php
	}
	endwhile; 
	endif;
	?>
	<div class="pagination">
	<?php themex_pagination(); ?>
	</div><!--/ pagination-->
	<div class="clear"></div>
</div><!--/ listing block-->
<?php get_footer(); ?>