<?php 
//show header
get_header();

//post content
if (have_posts()) : while (have_posts()) : the_post();
?>
<div class="column two-third"> 
	<?php if(get_post_meta($post->ID,'artist_profile_image',true)!='') { ?>
	<div class="artist-thumbnail">
		<img src="<?php echo THEMEX_URI.'extensions/timthumb/timthumb.php?src='.urlencode(get_post_meta($post->ID,'artist_profile_image',true)).'&amp;w=610'; ?>" class="fullwidth" alt="<?php the_title(); ?>" />
		<div class="ribbon-caption">
			<div class="ribbon-caption-title">
				<div class="artist-social-links">
					<?php if(get_post_meta($post->ID,'artist_google',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_google',true); ?>" class="google" title="Google "></a><?php } ?>
					<?php if(get_post_meta($post->ID,'artist_myspace',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_myspace',true); ?>" class="myspace" title="MySpace"></a><?php } ?>
					<?php if(get_post_meta($post->ID,'artist_lastfm',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_lastfm',true); ?>" class="lastfm" title="LastFM"></a><?php } ?>
					<?php if(get_post_meta($post->ID,'artist_blogger',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_blogger',true); ?>" class="blogger" title="Blogger"></a><?php } ?>
					<?php if(get_post_meta($post->ID,'artist_tumblr',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_tumblr',true); ?>" class="tumblr" title="Tumblr"></a><?php } ?>
					<?php if(get_post_meta($post->ID,'artist_facebook',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_facebook',true); ?>" class="facebook" title="Facebook"></a><?php } ?>
					<?php if(get_post_meta($post->ID,'artist_twitter',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_twitter',true); ?>" class="twitter" title="Twitter"></a><?php } ?>	
					<?php if(get_post_meta($post->ID,'artist_reverbnation',true)!='') { ?><a href="<?php echo get_post_meta($post->ID,'artist_reverbnation',true); ?>" class="reverbnation" title="ReverbNation"></a><?php } ?>
				</div>
				<span class="ribbon-caption-background"></span>
			</div>
		</div>
	</div>
	<?php } ?>
	<div class="content-block single-post">
		<div class="block-title"><span><?php _e('Biography','replay'); ?></span></div>
		<div class="block-content">
			<?php the_content(); ?>	
		</div>
	</div>
</div>
<?php endwhile; endif; ?>
<div class="one-third column last">
<?php 
//events
if(get_option('themex_artist_events')!='true') { 
	get_template_part('module','events');
} 

//videos
if(get_option('themex_artist_videos')!='true') { 
	get_template_part('module', 'videos');
} 

//gallery
if(get_option('themex_artist_galleries')!='true') {
	get_template_part('module', 'gallery');
}
if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar('Artist Sidebar') )
?>
</div><!--/ sidebar-->
<div class="clear"></div>
<?php 
//releases
if(get_option('themex_artist_releases')!='true') {	
	$releases_count=8;
	if(get_option('themex_artist_releases_count')) {
		$releases_count=intval(get_option('themex_artist_releases_count'));
	}

	$releases_order='date';
	if(get_option('themex_artist_releases_order')) {
		$releases_order=get_option('themex_artist_releases_order');
	}	
	
	$releases_filters=null;
	$releases_exclude=array();
	if($releases_order=='related') {
		$releases_filters=array('artists'=>$post->ID);
	}
	
	$releases_title=__('Releases','replay');	
	
	get_template_part('module','releases');
}

//show footer
get_footer(); 
?>