<?php 
/*
Template Name: Events
*/

//show header
get_header();

//page content
if (have_posts()) : while (have_posts()) : the_post();
	the_content();
endwhile; endif;

//date format
$date_format='d/m/Y';
if(get_option('themex_events_date_format')) {
	$date_format=get_option('themex_events_date_format');
}

//page layout
$layout=get_option('themex_events_layout');

if($layout=='left') {
?>
	<div class="one-third column">
		<?php get_sidebar(); ?>
	</div>
	<div class="two-third column last">
<?php } else { ?>
	<div class="two-third column">
<?php } ?>
	<div class="content-block">
		<div class="block-title"><span><?php _e('Upcoming Events', 'replay'); ?></span></div>
		<div class="block-content">
			<div class="events-list">
				<table>
					<?php
					//get events
					$events=themex_get_posts('event',array('ID','title','artists','date','place','video','gallery','link','status','details'),-1, array('event_category'=>get_post_meta($post->ID, 'page_events_category', true)));
					$current_time=time()-86400;
					
					//loop events
					foreach($events as $event) {
						if($event['timestamp']>=$current_time) {
					?>
					<tr>
						<td class="event-date"><?php echo date($date_format, $event['timestamp']); ?></td>
						<td class="event-title"><?php echo themex_event_title($event,'&#64;'); ?></td>
						<td class="event-place"><?php echo $event['place']; ?></td>
						<td class="event-option">							
							<?php if($event['status']=='active' && $event['link']) { ?>
							<a href="<?php echo $event['link']; ?>" target="_blank" class="button small"><span><?php _e('Buy Tickets','replay'); ?></span></a>
							<?php } else if($event['status']!='active') { ?>
							<span class="event-status">
							<?php
							if($event['status']=='free') {
								_e('Free Entry','replay'); 
							} else if($event['status']=='sold') {
								_e('Sold Out','replay');
							} else if($event['status']=='cancelled') { 
								_e('Cancelled','replay');
							} 
							?>	
							</span>
							<?php } ?>
						</td>
					</tr>
					<?php 
						}
					} 
					?>
				</table>
			</div>
		</div>
	</div>	
	<?php if(get_option('themex_events_past')!='true') { ?>
	<div class="content-block">
		<div class="block-title"><span><?php _e('Past Events', 'replay'); ?></span></div>
		<div class="block-content">
			<div class="events-list events-past">
				<table>
					<?php
					//get events
					$events=array_reverse($events);
					
					//loop events				
					foreach($events as $event) {
						if($event['timestamp']<$current_time) {
					?>
					<tr>
						<td class="event-date"><?php echo date($date_format, $event['timestamp']); ?></td>
						<td class="event-title"><?php echo themex_event_title($event,'&#64;'); ?></td>
						<td class="event-place"><?php echo $event['place']; ?></td>
						<td class="event-option">
							<?php
							if($event['gallery']!='default') { ?>
								<a class="attachment-icon gallery-icon" href="<?php echo get_permalink(intval($event['gallery'])); ?>" title="<?php _e('View Gallery','replay'); ?>"></a>
							<?php } ?>
							<?php 
							if($event['video']!='default') { ?>
								<a class="attachment-icon video-icon" href="<?php echo get_permalink(intval($event['video'])); ?>" title="<?php _e('Watch Video','replay'); ?>"></a>
							<?php } ?>
						</td>
					</tr>
					<?php
						}
					}
					?>					
				</table>
			</div>
		</div>
	</div>
	<?php } ?>
	</div>
<?php if($layout!='left') { ?>
<div class="one-third column last">
	<?php get_sidebar(); ?>
</div>
<?php } ?>
<?php get_footer(); ?>