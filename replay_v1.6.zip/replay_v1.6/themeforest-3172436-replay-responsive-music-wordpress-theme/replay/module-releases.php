<?php
global $releases_order, $releases_count, $releases_filters, $releases_title, $releases_exclude;

//get releases
$releases=themex_get_posts('release',array('ID','title','date','artists','permalink'),$releases_count,$releases_filters, $releases_order, $releases_exclude);

if(!empty($releases)) {
?>
<div class="clear"></div>
<div class="content-block carousel-slider-container">
	<div class="block-title">
		<span><?php echo $releases_title; ?></span>
		<?php if(count($releases)>4) { ?>
		<div class="arrow carousel-slider-arrow arrow-right"></div>
		<div class="arrow carousel-slider-arrow arrow-left"></div>
		<?php } ?>
	</div>
	<div class="block-content">
		<div class="carousel-slider">
			<ul>
				<?php
				$count=0;
				foreach($releases as $release) {
					$count++;
					if($count==1) {
						echo '<li>';
					}
				?>
				<div class="one-fourth-inner column <?php if($count==4) { echo 'last'; } ?>">
					<div class="release-thumbnail">
						<div class="release-cover">
							<a href="<?php echo $release['permalink']; ?>"><img src="<?php echo themex_thumbnail($release['ID'],440); ?>" class="fullwidth" alt="" /></a>
						</div>
						<h4 class="release-title"><a href="<?php echo $release['permalink']; ?>"><?php echo $release['title']; ?></a></h4>
						<h6 class="release-artist"><?php echo themex_artists($release['artists']); ?></h6>
						<div class="release-meta">
							<?php if(themex_links($release['ID'])!='') { ?>
							<div class="button-container">
								<a href="<?php echo $release['permalink']; ?>" class="button small"><span><?php _e('Buy Now','replay'); ?></span></a>
							</div>
							<?php } ?>
							<div class="release-info"><?php echo $release['date']; ?></div>
							<div class="clear"></div>						
						</div>
					</div>
				</div>
				<?php
					if($count==4) {
						echo '</li>';
						$count=0;						
					}				
				}
				if($count!=0) {
					echo '</li>';
				}
				?>
			</ul>
		</div>
	</div>
</div>
<?php } ?>