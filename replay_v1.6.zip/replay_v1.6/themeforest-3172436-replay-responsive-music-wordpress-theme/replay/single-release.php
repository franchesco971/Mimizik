<?php 
//show header
get_header();

//post content
if (have_posts()) : while (have_posts()) : the_post();
?>
<div class="one-fourth column">
	<div class="release-thumbnail">
		<div class="release-cover">
			<img src="<?php echo themex_thumbnail($post->ID,460); ?>" class="fullwidth" alt="" />
		</div>
		<h4 class="release-title"><?php the_title(); ?></h4>
		<h6 class="release-artist"><?php echo themex_artists(get_post_meta($post->ID,'release_artists',true)); ?></h6>
		<div class="release-meta">
			<?php
			//get buy links
			if(get_post_meta($post->ID,'release_links',true)!='') {
				parse_str(html_entity_decode(get_post_meta($post->ID,'release_links',true)),$links);
			}
			?>
			<?php echo themex_links($post->ID); ?>
			<div class="release-info"><?php echo get_post_meta($post->ID,'release_date',true); ?></div>
			<div class="clear"></div>								
		</div>
	</div>	
</div>
<div class="five-twelfth column">
	<div class="content-block">
		<div class="block-title">
			<span><?php _e('Review','replay'); ?></span>
		</div>
		<div class="block-content">
			<?php the_content(); ?>
		</div>
	</div>
</div>
<div class="one-third column last">
	<div class="content-block">
		<div class="block-title">
			<span><?php _e('Tracklist','replay'); ?></span>
		</div>
		<div class="block-content">
			<div class="track-list">
				<?php
				$tracks=array();
				parse_str(html_entity_decode(get_post_meta($post->ID,'release_tracks',true)),$tracks);
				?>
				<table>
					<?php
					$count=0;
					foreach($tracks as $track) {
					$count++;
					?>
					<tr>
						<td class="track-number"><?php echo $count; ?></td>
						<td><?php echo stripslashes_deep($track['title']); ?></td>
						<td class="track-duration"><span><?php echo $track['duration']; ?></span>
						<?php if($track['url']!='') { ?>
						<a title="<?php _e('Play','replay'); ?>" href="#" class="attachment-icon audio-icon track-play-button"></a>
						<?php } ?>
						</td>
					</tr>
					<?php if($track['url']!='') { ?>
					<tr class="track-player"><td colspan="3"><audio preload="none" src="<?php echo $track['url']; ?>"></audio></td></tr>
					<?php
						}
					}
					?>				
				</table>
			</div>						
		</div>
	</div>
</div>
<?php
endwhile; endif; 

//releases
if(get_option('themex_release_releases')!='true') {
	$releases_count=8;
	if(get_option('themex_release_releases_count')) {
		$releases_count=intval(get_option('themex_release_releases_count'));
	}
	
	$releases_order='date';
	if(get_option('themex_release_releases_order')) {
		$releases_order=get_option('themex_release_releases_order');
	}	
		
	$releases_filters=null;
	if($releases_order=='related') {
		$artists=array();
		parse_str(get_post_meta($post->ID,'release_artists',true),$artists);
		$releases_filters=array('artists'=>$artists);
	}
	
	$releases_title=__('Related Releases','replay');
	if($releases_order=='date') {
		$releases_title=__('Latest Releases','replay');
	} else if($releases_order=='rand') {
		$releases_title=__('Random Releases','replay');
	}

	$releases_exclude=array($post->ID);
	
	get_template_part('module','releases');
}

//footer
get_footer(); 
?>