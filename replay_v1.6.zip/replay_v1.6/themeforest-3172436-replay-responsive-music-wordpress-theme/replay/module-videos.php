<?php	
//get videos
$videos=themex_get_posts('video',array('ID','title','permalink'),-1,array('artists'=>$post->ID));
if(!empty($videos)) {
?>
<div class="content-block">
	<div class="block-title">
		<span><?php _e('Videos','replay'); ?></span>
		<?php if(count($videos)>1) { ?>
		<div class="arrow carousel-slider-arrow arrow-right"></div>
		<div class="arrow carousel-slider-arrow arrow-left"></div>
		<?php } ?>
	</div>
	<div class="block-content">
		<div class="fade-slider">
			<ul>
				<?php foreach($videos as $video) { ?>
				<li>
					<div class="video-thumbnail">
						<a href="<?php echo $video['permalink']; ?>"><img src="<?php echo themex_thumbnail($video['ID'],430) ?>" class="fullwidth" alt="" /></a>
						<a class="caption" href="<?php echo get_permalink($video['ID']); ?>">
							<span><?php echo $video['title']; ?></span>
						</a>
					</div>
				</li>
				<?php } ?>
			</ul>
		</div>
	</div>
</div>
<?php } ?>