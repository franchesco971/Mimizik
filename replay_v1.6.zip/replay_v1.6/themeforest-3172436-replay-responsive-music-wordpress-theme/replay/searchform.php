<form action="<?php echo home_url(); ?>" method="get">
    <fieldset>
        <input type="text" name="s" id="search" value="<?php if (isset($_GET['s'])) { the_search_query(); } else { _e('Search','replay'); } ?>" />
    </fieldset>
</form>