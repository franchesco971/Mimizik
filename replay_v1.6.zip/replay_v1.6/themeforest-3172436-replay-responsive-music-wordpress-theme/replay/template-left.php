<?php 
/*
Template Name: Left Sidebar
*/

//show header
get_header(); 
?>
<div class="one-third column">
	<?php get_sidebar(); ?>
</div>
<?php
//page content
if (have_posts()) : while (have_posts()) : the_post();
?>
<div class="two-third column last">
	<?php the_content(); ?>
</div>
<?php endwhile; endif; ?>
<?php get_footer(); ?>