<?php
//get galleries
$galleries=themex_get_posts('gallery',array('ID','title', 'permalink'),-1,array('artists'=>$post->ID));
if(!empty($galleries)) {
?>
<div class="content-block">
	<div class="block-title">
		<span><?php _e('Gallery','replay'); ?></span>
		<?php if(count($galleries)>1) { ?>
		<div class="arrow carousel-slider-arrow arrow-right"></div>
		<div class="arrow carousel-slider-arrow arrow-left"></div>
		<?php } ?>
	</div>
	<div class="block-content">
		<div class="fade-slider">
			<ul>
				<?php foreach($galleries as $gallery) { ?>
				<li>
					<div class="gallery-thumbnail">
						<a href="<?php echo $gallery['permalink']; ?>"><img src="<?php echo themex_thumbnail($gallery['ID'],440) ?>" class="fullwidth" alt="" /></a>
						<a class="caption" href="<?php echo get_permalink($gallery['ID']); ?>">
							<span><?php echo $gallery['title']; ?></span>
						</a>
					</div>
				</li>
				<?php } ?>
			</ul>
		</div>
	</div>
</div>
<?php } ?>